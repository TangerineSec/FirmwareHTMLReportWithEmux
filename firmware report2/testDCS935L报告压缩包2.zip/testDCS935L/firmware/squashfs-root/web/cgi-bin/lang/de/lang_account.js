﻿var languageNum = new Array("en","sc","tc");
var item_name = new Array("D-Link Corporation", "Wireless", "INTERNET CAMERA",
"Live Video",
"Benutzername",
"Neues Kennwort",
"Kennwort wiederholen",
"Übernehmen",
"Löschen",
"Beenden",
""
);
var I_DINK_CORPORATION = 0;
var I_WIRELESS = 1;
var I_INTERNET_CAMERA = 2;
var I_LIVE_VIDEO = 3;
var I_USER_NAME = 4;
var I_NEW_PWD = 5;
var I_RETYPE_PWD = 6;
var I_APPLY = 7;
var I_CLEAR = 8;
var I_EXIT = 9;

var pop_msg = new Array(
"Sie haben ein falsches Kennwort eingegeben. Versuchen Sie es bitte noch einmal.",
"Das Kennwort wurde nicht korrekt bestätigt. Stellen Sie sicher, dass das neue Kennwort und das von Ihnen zur Bestätigung erneut eingegebene Kennwort übereinstimmen.",
""
);

var P_PWD_INCORRECT = 0;
var P_PWD_RETYPE_INCORRECT = 1;

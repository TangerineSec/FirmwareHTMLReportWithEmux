﻿var languageNum = new Array("en","sc","tc");
var item_name = new Array("Standortübersicht", "Aktualisieren", "Sprache",
"Beenden", 
"Anschließen",
"SSID",
"BSSID",
"Kanal",
"Verschlüsselung",
"D/I Signal %",
"Suchen",
"Ad-Hoc",
"Infrastruktur",
"Automatisch",
"Keine",
"WEP",
"WPA-PSK",
"WPA2-PSK",
"WPA-PSK/WPA2-PSK",
""
);

var I_SITE_SURVEY = 0;
var I_REFRESH = 1;
var I_SELECT = 2;
var I_EXIT = 3;
var I_JOIN = 4;
var I_SSID = 5;
var I_BSSID = 6;
var I_CHANNEL = 7;
var I_ENCRYPTION = 8;
var I_SIGNAL = 9;
var I_SEARCHING = 10;
var I_ADHOC = 11;
var I_INFRASTRUCTURE = 12;
var I_AUTOMATIC = 13;
var I_NO = 14;
var I_WEP = 15;
var I_WPAPSK = 16;
var I_WPA2PSK = 17;
var I_WPAWPA2PSK = 18;

var des_item_name = new Array (
"Führt einen Scan durch und zeigt alle verfügbaren drahtlosen Netze in der Geräteumgebung an. \
Klicken Sie auf <b>Refresh</b> (Aktualisieren), um den Scan erneut durchzuführen. \
Wählen Sie ein drahtloses Netzwerk und klicken Sie dann auf <b>Select</b> (Auswählen), um fortzufahren.",
""
);

var D_TITLE_INFO = 0;

var pop_msg = new Array (
"Bei der Anfrage ist ein Problem aufgetreten.",
""
);

var PMSG_REQUEST_FAILED = 0;

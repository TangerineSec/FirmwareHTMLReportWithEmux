﻿var languageNum = new Array("en","sc","tc");
var item_name = new Array("Standardwerte wiederherstellen",
""
);
var I_RESTORE_FACTORY_DEFAULT = 0;

var des_item_name = new Array (
"Die Einstellungen der Kamera wurden auf die werkseitigen Einstellungen zurückgesetzt. \
<br><br>Die Kamera wird neu gestartet. Das kann bis zu 60 Sekunden dauern.  \
<br><br>Die Verbindung zur Kamera wurde getrennt. Wenn die Webseite der Kamera nicht automatisch nach dem Neustart angezeigt werden kann, \
verwenden Sie den Setup-Assistenten Ihrer Kamera, um einen Suchvorgang einzuleiten und eine Verbindung zur Kamera herzustellen.\
<br><br>Warten Sie bitte <SPAN ID=\"CountTime\"></SPAN> Sekunden...",
""
);

var D_FACTORY_INFO = 0;
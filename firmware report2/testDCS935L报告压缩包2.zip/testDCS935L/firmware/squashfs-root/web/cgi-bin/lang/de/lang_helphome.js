﻿var languageNum = new Array("en","sc","tc");
var item_name = new Array("SUPPORT-MENÜ", "Kamera",
""
);
var I_SUPPORT_MENU = 0;
var I_CAMERA = 1;

var des_item_name = new Array (
"<b>H.264</b> - Verwenden Sie H.264 Streaming zur Anzeige der Live Videobilder der Kamera. Auf Ihrem \
Computer muss Java installiert sein, damit Sie H.264 zur Anzeige der Live Videobilder der Kamera verwenden können.\
 Falls Ihr Browser nicht der Internet Explorer Browser ist, rufen Sie im Internet die Seite \
 <a href=\"http://www.java.com\">http://www.java.com</A> auf, um Java herunterzuladen und zu installieren.<br><br>",
"<b>MJPEG </b> - Verwenden Sie MJPEG Streaming zur Anzeige der Live Videobilder der Kamera. \
Auf Ihrem Computer muss Java installiert sein, damit Sie MJPEG zur Anzeige der Live Videobilder der Kamera verwenden können. \
Rufen Sie im Internet die Seite <a href=\"http://www.java.com\">http://www.java.com</A> auf, um Java herunterzuladen und zu installieren.<br><br>",
"<b>Zoom</b> - Mithilfe der digitalen Zoom-Funktion können Bilder bis auf das Achtfachen vergrößert angezeigt werden.<br><br>",
"<b>Audio On/Off</b> - (Audio Ein/Aus) Durch Drücker auf 'Aus' können Sie die Audioüberwachung ausschalten. Mit 'Ein' schalten Sie sie wieder ein.<br><br>",
"<b>Night Mode On/Off</b> (Nachtmodus Ein/Aus) - Sie können die Taste zur manuellen Einstellung der Tag/Nachtfunktion Ihrer Kamera verwenden. \
Wenn Sie diese Option verwenden möchten, müssen Sie zuerst den Tag/Nachtmodus auf ‘Manuell’ setzen.<br><br>",
""
);

var D_H264 = 0;
var D_MJPEG = 1;
var D_ZOOM = 2;
var D_AUDIO = 3;
var D_NIGHT_MODE = 4;

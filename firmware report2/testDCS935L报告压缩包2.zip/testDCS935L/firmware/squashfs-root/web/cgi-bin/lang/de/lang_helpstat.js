﻿var languageNum = new Array("en","sc","tc");
var item_name = new Array("SUPPORT-MENÜ", "Geräte-Info", "Systemprotokoll",
"Event-Protokoll",
""
);
var I_SUPPORT_MENU = 0;
var I_DEVICE_INFO = 1;
var I_SYSTEM_LOG = 2;
var I_EVENT_LOG = 3;

var des_item_name = new Array (
"Diese Seite zeigt alle Informationen über die Kamera und die Netzwerkeinstellungen an.",
"Zeigt die Systemprotokolldatei an. Diese Datei bietet Ihnen nützliche Informationen z. B. Systemmeldungen.",
"Zeigt die Ereignisprotokolldatei an. Diese Datei bietet Ihnen nützliche Informationen wie beispielsweise Bewegungserkennungsmeldungen.",
""
);

var D_DEVICE_INFO = 0;
var D_SYSTEM_LOG_INFO = 1;
var D_EVENT_LOG_INFO = 2;

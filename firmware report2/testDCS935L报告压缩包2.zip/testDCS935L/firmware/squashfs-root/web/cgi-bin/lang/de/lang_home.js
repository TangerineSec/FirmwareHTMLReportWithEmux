﻿var languageNum = new Array("en","sc","tc");
var item_name = new Array("D-Link Corporation", "Wireless", "INTERNET CAMERA",
"Live Video",
"Produkt", 
"Firmware-Version", 
"Live Video",
"SETUP",
"WARTUNG",
"Status",
"Hilfe",
"Kamera",
"Abmelden",
"Richten auf",
"Pan Step",
"Tilt Step",
"Sprache",
"Indikator für die Bewegungs-/Tonerkennung",
"Aufnahmeanzeige",
"Digitale Eingabeanzeige",
""
);
var I_DINK_CORPORATION = 0;
var I_WIRELESS = 1;
var I_INTERNET_CAMERA = 2;
var I_LIVE_VIDEO = 3;
var I_PRODUCT = 4;
var I_FWVERSION = 5;
var I_LIVE_VIDEO_2 = 6;
var I_SETUP = 7;
var I_MAINTENANCE = 8;
var I_STATUS = 9;
var I_HELP = 10;
var I_CAMERA = 11;
var I_LOGOUT = 12;
var I_GOTO = 13;
var I_PAN_STEP = 14;
var I_TILT_STEP = 15;
var I_LANGUAGE = 16;
var I_MD_AD_INDICATOR = 17;
var I_RECORD_INDICATOR = 18;
var I_INPUT_INDICATOR = 19;

var des_item_name = new Array (
"Urheberrecht 2014, D-Link Corporation / D-Link Systems, Inc. Alle Rechte vorbehalten.",
""
);

var D_COPYRIGHT = 0;

var option_content = new Array (
"English",
"简体中文",
"繁體中文",
"Deutsch",
"Español",
"Italiano",
"Français",
"-- Wählen Sie eins --",
""
);

var O_LANG_EN = 0;
var O_LANG_SC = 1;
var O_LANG_TC = 2;
var O_LANG_DE = 3;
var O_LANG_ES = 4;
var O_LANG_IT = 5;
var O_LANG_FR = 6;
var O_SEL_POS = 7;

var pop_msg = new Array (
"Es gab ein Problem mit der Anfrage.",
""
);

var PMSG_REQUEST_FAILED = 0;

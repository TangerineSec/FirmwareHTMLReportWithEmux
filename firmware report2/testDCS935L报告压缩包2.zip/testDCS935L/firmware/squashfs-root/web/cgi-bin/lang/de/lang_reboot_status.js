﻿var languageNum = new Array("en","sc","tc");
var item_name = new Array("Reboot the device",
""
);
var I_REBOOT_THE_DEVICE = 0;

var des_item_name = new Array (
"Die Kamera wird neu gestartet. Das kann bis zu 60 Sekunden dauern.\
<br><br> Die Verbindung zur Kamera wurde getrennt. Wenn die Webseite der Kamera nicht automatisch nach dem Neustart angezeigt werden kann, \
verwenden Sie den Setup-Assistenten Ihrer Kamera, um einen Suchvorgang einzuleiten und eine Verbindung zur Kamera herzustellen.\
<br><br>Warten Sie bitte <SPAN ID=\"CountTime\"></SPAN> Sekunden...",
""
);

var D_REBOOT_INFO = 0;
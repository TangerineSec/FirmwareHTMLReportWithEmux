﻿var languageNum = new Array("en","sc","tc");
var item_name = new Array("Einstellungen speichern", "Einstellungen nicht speichern", "Speichern",
"Sound Detection", 
"Sound Detection-Setup",
"Sound Detection",
"Aktivieren",
"Deaktivieren",
"Detection Level",
"Sens Up",
""
);

var I_SAVE_SETTING = 0;
var I_NOT_SAVE_SETTING = 1;
var I_SAVING = 2;
var I_SOUND_DETECTION = 3;
var I_SOUND_DETECTION_SETTING = 4;
var I_SOUND_DETECTION_ITEM = 5;
var I_ENABLE = 6;
var I_DISABLE = 7;
var I_LEVEL = 8;
var I_DB = 9;

var des_item_name = new Array (
"In diesem Abschnitt können Sie die Tonerkennung für Ihre Kamera konfigurieren.<br><br>Beachten Sie bitte, dass auf Ihrem Computer \
Java installiert sein muss, damit das Fenster 'Ton dB/Zeit' angezeigt werden kann. Falls Sie das Fenster 'Ton dB/Zeit' unten nicht sehen, \
rufen Sie im Internet die Seite <a href=\"http://www.java.com\">http://www.java.com</A>auf, um Java herunterzuladen und zu installieren.",
"Das Mikrofon ist deaktiviert. Aktivieren Sie es bitte.",
""
);

var D_TITLE_INFO = 0;
var D_MICROPHONE_DISABLED = 1;

var pop_msg = new Array (
"Bei der Anfrage ist ein Problem aufgetreten.",
""
);

var PMSG_REQUEST_FAILED = 0;

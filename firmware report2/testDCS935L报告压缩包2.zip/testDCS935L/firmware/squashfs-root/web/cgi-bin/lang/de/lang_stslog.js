﻿var languageNum = new Array("en","sc","tc");
var item_name = new Array("Systemprotokoll", "AKTUELLES PROTOKOLL", "Aktualisieren",
"Aktualisieren",
""
);
var I_SYSTEM_LOG = 0;
var I_CURRENT_LOG = 1;
var I_REFRESH = 2;
var I_REFRESHING = 3;

var des_item_name = new Array (
"Im Systemprotokoll werden die vorgefallenen Kamera-Systemereignisse erfasst.",
"<b>Nützliche Hinweise..</b><br><br>Sie können das Protokoll aktualisieren, indem Sie auf die entsprechende Schaltfläche klicken.",
""
);

var D_SYSTEM_LOG_INFO = 0;
var D_HELP_INFO = 1;

﻿var languageNum = new Array("en","sc","tc");
var item_name = new Array("Datei-Hochladepfad", "Firmware-Upgrade abgeschlossen", "Auf Ihrem Gerät wird jetzt ein Firmware-Upgrade durchgeführt.",
"Ungültige Datei",
"Auf Ihrem Gerät wird jetzt ein Firmware-Upgrade durchgeführt. Bitte warten Sie. Dieser Vorgang kann bis zu 240 Sekunden dauern.",
"Sekunden",
""
);
var I_UPGRADE = 0;
var I_FIRMWARE_UPGRADE_OK = 1;
var I_FIRMWARE_IS_RUNNING = 2;
var I_FILE_INVALID = 3;
var I_WAIT_FW_RUNNING = 4;
var I_SEC = 5;

﻿var languageNum = new Array("en","sc","tc");
var item_name = new Array("INTERNETVERBINDUNGS-EINSTELLUNGEN", "Setup-Assistent für die Internetverbindung", "Configurazione manuale connessione Internet",
""
);
var I_INTERNET_CONNECTION_SETTING = 0;
var I_INTERNET_CONNECTION_SETUP = 1;
var I_MANAUAL_INTERNET_CONNECTION_SETUP = 2;

var des_item_name = new Array (
"In diesem Abschnitt können Sie die Einstellungen der Netzwerkschnittstellen Ihrer IP-Kamera vornehmen. \
Wenn Sie dieses Gerät zum ersten Mal konfigurieren, empfiehlt D-Link, auf die Schaltfläche \"Internet Connection Setup Wizard (Setup-Assistent für die \
Internetverbindung) zu klicken und den Anweisungen auf dem Bildschirm zu folgen. Wenn Sie die IP-Kameraeinstellungen manuell \
ändern oder konfigurieren möchten, klicken Sie auf die Schaltfäche \"Manuelle Einrichtung der Internetverbindung\" (Manual Internet \
Connection Setup).",
"<b>Nützliche Hinweise..</b><br><br>Sollten Sie als erfahrener Benutzer bereits mit der Konfiguration einer Internetkamera vertraut sein, \
klicken Sie auf \'Manual Internet Connection Setup\' (Manuelle Einrichtung der Internetverbindung), um alle Einstellungen manuell vorzunehmen.",
""
);

var D_WIZARD_INFO = 0;
var D_HELP_INFO = 1;

var pop_msg = new Array (
"Bei der Anfrage ist ein Problem aufgetreten.",
""
);

var PMSG_REQUEST_FAILED = 0;

﻿var languageNum = new Array("en","sc","tc");
var item_name = new Array("D-Link Corporation", "Wireless", "INTERNET CAMERA",
"Live Video",
"Produkt", 
"Firmware-Version", 
"Willkommen beim Setup-Assistenten für Internetverbindungen von D-Link",
"Zurück",
"Abbrechen",
"Abbrechen",
""
);
var I_DINK_CORPORATION = 0;
var I_WIRELESS = 1;
var I_INTERNET_CAMERA = 2;
var I_LIVE_VIDEO = 3;
var I_PRODUCT = 4;
var I_FWVERSION = 5;
var I_TITLE = 6;
var I_BACK = 7;
var I_NEXT = 8;
var I_CANCEL = 9;

var des_item_name = new Array (
"Copyright 2014, D-Link Corporation / D-Link Systems, Inc. Alle Rechte vorbehalten.",
"Dieser Assistent führt Sie Schritt für Schritt durch den Konfigurationsprozess Ihrer neuen \
D-Link-Kamera und hilft Ihnen, eine Verbindung der Kamera zum Internet herzustellen.<br><br>",
"<b>Schritt 1:</b> LAN-Einstellungen vornehmen",
"<b>Schritt 2:</b> DDNS-Einstellungen vornehmen",
"<b>Schritt 3:</b> Servernamen-Einstellungen",
"<b>Schritt 4:</b> Zeitzone einrichten",
""
);

var D_COPYRIGHT = 0;
var D_TITLE_IFNO = 1;
var D_SETP1_INFO = 2;
var D_SETP2_INFO = 3;
var D_SETP3_INFO = 4;
var D_SETP4_INFO = 5;

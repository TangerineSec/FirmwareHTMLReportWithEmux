﻿var languageNum = new Array("en","sc","tc");
var item_name = new Array("D-Link Corporation", "Wireless", "INTERNET CAMERA",
"Live Video",
"Produkt", 
"Firmware-Version",
"Servername",
"Zurück",
"Weiter",
"Löschen",
"IP Camera Name",
"Maximal {$10} Zeichen",
""
);
var I_DINK_CORPORATION = 0;
var I_WIRELESS = 1;
var I_INTERNET_CAMERA = 2;
var I_LIVE_VIDEO = 3;
var I_PRODUCT = 4;
var I_FWVERSION = 5;
var I_TITLE = 6;
var I_BACK = 7;
var I_NEXT = 8;
var I_CANCEL = 9;
var I_CAMERA_NAME = 10;
var I_CAMERA_NAME_LENGTH_DES = 11;

var des_item_name = new Array (
"Copyright 2014, D-Link Corporation / D-Link Systems, Inc. Alle Rechte vorbehalten.",
"Um den Zugriff zu erleichtern, empfiehlt D-Link Ihrer Kamera einen neuen Namen zu geben. Weisen Sie bitte einen Namen zu, bevor Sie auf\
<b>Next</b> (Weiter) klicken.<br><br>",
""
);

var D_COPYRIGHT = 0;
var D_TITLE_IFNO = 1;

var pop_msg = new Array (
"Bei der Anfrage ist ein Problem aufgetreten.",
"Der Kameraname ist ungültig.",
""
);

var PMSG_REQUEST_FAILED = 0;
var PMSG_CAMERA_NAME_INVALID = 1;


﻿var languageNum = new Array("en","sc","tc");
var item_name = new Array("D-Link Corporation", "Wireless", "INTERNET CAMERA",
"Live Video",
"Produkt", 
"Firmware-Version",
"Schritt 5: Setup abgeschlossen.",
"Zurück",
"Übernehmen",
"Löschen",
"Start-IP-Adresse",
"IP Camera Name",
"Sommerzeit aktivieren",
"DynDNS",
"DHCP",
"PPPoE",
"Diese Aufnahme aktivieren",
"Deaktivieren",
""
);
var I_DINK_CORPORATION = 0;
var I_WIRELESS = 1;
var I_INTERNET_CAMERA = 2;
var I_LIVE_VIDEO = 3;
var I_PRODUCT = 4;
var I_FWVERSION = 5;
var I_TITLE = 6;
var I_BACK = 7;
var I_NEXT = 8;
var I_CANCEL = 9;
var I_IP_ADDRESS = 10;
var I_CAMERA_NAME = 11;
var I_TIMEZONE = 12;
var I_DDNS = 13;
var I_DHCP = 14;
var I_PPPOE = 15;
var I_ENABLE = 16;
var I_DISABLE = 17;

var des_item_name = new Array (
"Copyright 2014, D-Link Corporation / D-Link Systems, Inc. Alle Rechte vorbehalten.",
"Hier finden Sie eine Übersicht der Einstellungen Ihrer Kamera. Klicken Sie auf <b>Back</b> (Zurück), \
um Ihre Einstellungen zu prüfen oder zu ändern, oder klicken Sie auf <b>Apply</b> (Übernehmen) , wenn alle Einstellungen \
korrekt sind. Notieren Sie sich diese Informationen, um bei Bedarf darauf zurückgreifen zu können.<br><br>",
""
);

var D_COPYRIGHT = 0;
var D_TITLE_IFNO = 1;

var pop_msg = new Array (
"Bei der Anfrage ist ein Problem aufgetreten.",
""
);

var PMSG_REQUEST_FAILED = 0;


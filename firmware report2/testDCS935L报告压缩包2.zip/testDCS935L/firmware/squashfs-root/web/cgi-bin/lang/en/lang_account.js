﻿var languageNum = new Array("en","sc","tc");
var item_name = new Array("D-LINK CORPORATION", "WIRELESS", "INTERNET CAMERA",
"LIVE VIDEO",
"User Name",
"New Password",
"Retype Password",
"Apply",
"Clear",
"   Exit   ",
""
);
var I_DINK_CORPORATION = 0;
var I_WIRELESS = 1;
var I_INTERNET_CAMERA = 2;
var I_LIVE_VIDEO = 3;
var I_USER_NAME = 4;
var I_NEW_PWD = 5;
var I_RETYPE_PWD = 6;
var I_APPLY = 7;
var I_CLEAR = 8;
var I_EXIT = 9;

var pop_msg = new Array(
"You have entered an incorrect password. Please try again.",
"The password was not correctly confirmed. Please ensure that the new password and retype password match exactly.",
""
);

var P_PWD_INCORRECT = 0;
var P_PWD_RETYPE_INCORRECT = 1;

﻿var languageNum = new Array("en","sc","tc");
var item_name = new Array("EVENT LOG", "CURRENT LOG", "Refresh",
"Refreshing",
""
);
var I_EVENT_LOG = 0;
var I_CURRENT_LOG = 1;
var I_REFRESH = 2;
var I_REFRESHING = 3;

var des_item_name = new Array (
"The event log records camera events that have occurred.",
"<b>Helpful Hints..</b><br><br>You can you can refresh the log by clicking on the Refresh button.",
""
);

var D_EVENT_LOG_INFO = 0;
var D_HELP_INFO = 1;

﻿var languageNum = new Array("en","sc","tc");
var item_name = new Array("SUPPORT MENU", "Camera",
""
);
var I_SUPPORT_MENU = 0;
var I_CAMERA = 1;

var des_item_name = new Array (
"<b>H.264</b> - Use H.264 streaming to view the camera&#39;s live video. Your computer needs to have \
Java installed in order to use H.264 to view the camera&#39;s live video if your Browser is not IE \
Browser, please visit <a href=\"http://www.java.com\">http://www.java.com</A> to download and install Java.<br><br>",
"<b>MJPEG </b> - Use MJPEG streaming to view the camera&#39;s live video. \
Your computer needs to have Java installed in order to use MJPEG to view the camera&#39;s live \
video, please visit <a href=\"http://www.java.com\">http://www.java.com</A> to download and install Java.<br><br>",
"<b>Zoom</b> - Zoom is a digital zoom. It allows you to magnify images by up to 8x.<br><br>",
"<b>Audio On/Off</b> - You can mute the audio by pressing the Off button. Press the On button to monitor the audio again.<br><br>",
"<b>Night Mode On/Off</b> - You can use the button to manually set the day/night function of the camera. \
In order to use this option, first set the Day/Night Mode setting to Manual.<br><br>",
""
);

var D_H264 = 0;
var D_MJPEG = 1;
var D_ZOOM = 2;
var D_AUDIO = 3;
var D_NIGHT_MODE = 4;

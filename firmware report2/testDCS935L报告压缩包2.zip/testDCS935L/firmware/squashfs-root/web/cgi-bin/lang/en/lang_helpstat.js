﻿var languageNum = new Array("en","sc","tc");
var item_name = new Array("SUPPORT MENU", "Device Info", "System Log",
"Event Log",
""
);
var I_SUPPORT_MENU = 0;
var I_DEVICE_INFO = 1;
var I_SYSTEM_LOG = 2;
var I_EVENT_LOG = 3;

var des_item_name = new Array (
"This page displays all the information about the camera and network settings.",
"View the system log file. This file reveals all the useful information like system boot messages.",
"View the event log file. This file reveals all the useful information like motion detection messages.",
""
);

var D_DEVICE_INFO = 0;
var D_SYSTEM_LOG_INFO = 1;
var D_EVENT_LOG_INFO = 2;

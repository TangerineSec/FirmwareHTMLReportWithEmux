﻿var languageNum = new Array("en","sc","tc");
var item_name = new Array("D-LINK CORPORATION", "WIRELESS", "INTERNET CAMERA",
"LIVE VIDEO",
"LOGOUT",
"Logging out will close the browser.",
"Please close web page manually.",
" Logout ",
""
);
var I_DINK_CORPORATION = 0;
var I_WIRELESS = 1;
var I_INTERNET_CAMERA = 2;
var I_LIVE_VIDEO = 3;
var I_LOGOUT = 4;
var I_LOGOUT_CLICK_CLOSE_BROWSER = 5;
var I_LOGOUT_MANUALLY_CLOSE = 6;
var I_LOGOUT_2 = 7;

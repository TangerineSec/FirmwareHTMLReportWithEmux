﻿var languageNum = new Array("en","sc","tc");
var item_name = new Array("Reboot the Device",
""
);
var I_REBOOT_THE_DEVICE = 0;

var des_item_name = new Array (
"The camera is restarting. It may take up to 60 seconds to reboot.<br><br>\
Connection with the camera has been cut. If the camera\'s web page is not \
automatically displayed after reboot, use the setup wizard software \
provided with your camera to search for and connect to the camera.<br><br>\
Please wait for <SPAN ID=\"CountTime\"></SPAN> seconds ...",
""
);

var D_REBOOT_INFO = 0;
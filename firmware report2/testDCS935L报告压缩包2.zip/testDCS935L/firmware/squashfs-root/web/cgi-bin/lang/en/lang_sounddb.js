﻿var languageNum = new Array("en","sc","tc");
var item_name = new Array(" Save Settings ", " Don't Save Settings ", "Saving",
"Sound Detection", 
"Sound Detection Settings",
"Sound Detection",
"Enable",
"Disable",
"Detection Level",
"dB",
""
);

var I_SAVE_SETTING = 0;
var I_NOT_SAVE_SETTING = 1;
var I_SAVING = 2;
var I_SOUND_DETECTION = 3;
var I_SOUND_DETECTION_SETTING = 4;
var I_SOUND_DETECTION_ITEM = 5;
var I_ENABLE = 6;
var I_DISABLE = 7;
var I_LEVEL = 8;
var I_DB = 9;

var des_item_name = new Array (
"In this section, you can configure the sound detection settings for your \
camera.<br><br>Please note that your computer needs to have Java installed in \
order to view the sound dB/Time window. If you do not see the sound \
dB/Time window below, please visit <a href=\"http://www.java.com\">\
http://www.java.com</A> to download and install Java.",
"Microphone is disabled, please enable microphone.",
""
);

var D_TITLE_INFO = 0;
var D_MICROPHONE_DISABLED = 1;

var pop_msg = new Array (
"There was a problem with the request.",
""
);

var PMSG_REQUEST_FAILED = 0;

﻿var languageNum = new Array("en","sc","tc");
var item_name = new Array("Support Menu", "Live Video", "Setup",
"Maintenance",
"Status",
"Camera",
"Wizard",
"Network Setup",
"Wireless Setup",
"Extender Setup",
"Dynamic DNS",
"IP Filter",
"Image Setup",
"Audio and Video",
"Privacy Mask",
"Motion Detection",
"Sound Detection",
"Mail",
"FTP",
"Snapshot",
"Video Clip",
"Time and Date",
"Day/Night Mode",
"Admin",
"System",
"Firmware Upgrade",
"Device Info",
"System Log",
"Event Log",
"SD Management",
""
);
var I_SUPPORT_MENU = 0;
var I_LIVE_VIDEO = 1;
var I_SETUP = 2;
var I_MAINTENANCE = 3;
var I_STATUS = 4;
var I_CAMERA = 5;
var I_WIZARD = 6;
var I_NETWORK_SETUP = 7;
var I_WIRELESS_SETUP = 8;
var I_EXTENDER_SETUP = 9;
var I_DYNAMIC_DNS = 10;
var I_IPFILTER = 11;
var I_IMAGE_SETUP = 12;
var I_AUDIO_AND_VIDEO = 13
var I_PRIVACY_MASK = 14;
var I_MOTION_DETECTION = 15;
var I_SOUND_DETECTION = 16;
var I_MAIL = 17;
var I_FTP = 18;
var I_SNAPSHOT = 19;
var I_VIDEO_CLIP = 20;
var I_TIME_AND_DATE = 21;
var I_DAY_NIGHT_MODE = 22;
var I_ADMIN = 23;
var I_SYSTEM = 24;
var I_FIRMWARE_UPGRADE = 25;
var I_DEVICE_INFO = 26;
var I_SYSTEM_LOG = 27;
var I_EVENT_LOG = 28;
var I_SD_MANAGEMENT = 29;
﻿var languageNum = new Array("en","sc","tc");
var item_name = new Array("UPGRADE", "Firmware upgrade completed.", "A firmware upgrade is now being performed on your device.",
"Invalid file!",
"A firmware upgrade is now being performed on your device. Please wait, as it may take up to 240 seconds to complete this process.",
"seconds",
""
);
var I_UPGRADE = 0;
var I_FIRMWARE_UPGRADE_OK = 1;
var I_FIRMWARE_IS_RUNNING = 2;
var I_FILE_INVALID = 3;
var I_WAIT_FW_RUNNING = 4;
var I_SEC = 5;

﻿var languageNum = new Array("en","sc","tc");
var item_name = new Array("INTERNET CONNECTION SETTINGS", "Internet Connection Setup Wizard", "Manual Internet Connection Setup",
""
);
var I_INTERNET_CONNECTION_SETTING = 0;
var I_INTERNET_CONNECTION_SETUP = 1;
var I_MANAUAL_INTERNET_CONNECTION_SETUP = 2;

var des_item_name = new Array (
"In this section, you can setup the IP camera\'s network interface settings. \
If you are configuring this device for the first time, D-Link recommends \
that you click the Internet Connection Setup Wizard button, and follow \
the instructions on screen. If you wish to modify or configure the IP \
camera settings manually, click the Manual Internet Connection Setup \
button.<br><br>",
"<b>Helpful Hints..</b><br><br>If you are an advanced user and have configured an Internet \
camera before, click \'Manual Internet Connection Setup\' to input all the \
settings manually.",
""
);

var D_WIZARD_INFO = 0;
var D_HELP_INFO = 1;

var pop_msg = new Array (
"There was a problem with the request.",
""
);

var PMSG_REQUEST_FAILED = 0;

﻿var languageNum = new Array("en","sc","tc");
var item_name = new Array("D-LINK CORPORATION", "WIRELESS", "INTERNET CAMERA",
"LIVE VIDEO",
"Product", 
"Firmware version", 
"welcome to d-link setup wizard - internet connection setup",
"Back",
"Next",
"Cancel",
""
);
var I_DINK_CORPORATION = 0;
var I_WIRELESS = 1;
var I_INTERNET_CAMERA = 2;
var I_LIVE_VIDEO = 3;
var I_PRODUCT = 4;
var I_FWVERSION = 5;
var I_TITLE = 6;
var I_BACK = 7;
var I_NEXT = 8;
var I_CANCEL = 9;

var des_item_name = new Array (
"Copyright 2014, D-Link Corporation / D-Link Systems, Inc. All rights reserved.",
"This wizard will guide you through a step-by-step process to \
configure your new D-Link Camera and connect the camera to the \
internet.<br><br>",
"<b>Step 1:</b> Setup LAN Settings",
"<b>Step 2:</b> Setup DDNS Settings",
"<b>Step 3:</b> Server Name Settings",
"<b>Step 4:</b> Setup Time Zone",
""
);

var D_COPYRIGHT = 0;
var D_TITLE_IFNO = 1;
var D_SETP1_INFO = 2;
var D_SETP2_INFO = 3;
var D_SETP3_INFO = 4;
var D_SETP4_INFO = 5;

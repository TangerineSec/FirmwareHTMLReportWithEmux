﻿var languageNum = new Array("en","sc","tc");
var item_name = new Array("D-LINK CORPORATION", "WIRELESS", "INTERNET CAMERA",
"LIVE VIDEO",
"Product", 
"Firmware version",
"step 1: setup lan settings",
"Back",
"Next",
"Cancel",
"DHCP Connection",
"Static IP Address",
"IP Address",
"Subnet Mask",
"Default Gateway",
"Primary DNS",
"Secondary DNS",
"PPPoE",
"User ID",
"Password",
""
);
var I_DINK_CORPORATION = 0;
var I_WIRELESS = 1;
var I_INTERNET_CAMERA = 2;
var I_LIVE_VIDEO = 3;
var I_PRODUCT = 4;
var I_FWVERSION = 5;
var I_TITLE = 6;
var I_BACK = 7;
var I_NEXT = 8;
var I_CANCEL = 9;
var I_DHCP = 10;
var I_STATIC_IP = 11;
var I_IP_ADDRESS = 12;
var I_SUBNET_MASK = 13;
var I_DEFAULT_GATEWAY = 14;
var I_DNS1 = 15;
var I_DNS2 = 16;
var I_PPPOE = 17;
var I_UID = 18;
var I_PWD = 19;

var des_item_name = new Array (
"Copyright 2014, D-Link Corporation / D-Link Systems, Inc. All rights reserved.",
"This wizard will guide you through a step-by-step process to \
configure your new D-Link Camera and connect the camera to the \
internet.<br><br>",
""
);

var D_COPYRIGHT = 0;
var D_TITLE_IFNO = 1;

var pop_msg = new Array (
"There was a problem with the request.",
"The IP Address is invalid.",
"The Subnet Mask is invalid.",
"The Default Gateway is invalid.",
"You enter incorrect TCP/IP configuration.",
"The format of User ID is invalid.",
"The format of Password is invalid.",
"The Primary DNS is invalid.",
"The Secondary DNS is invalid.",
"The format of Port Number is invalid.",
"The format of Bonjour Name is invalid.",
""
);

var PMSG_REQUEST_FAILED = 0;
var PMSG_INVALID_IPADDRESS = 1;
var PMSG_INVALID_SUBNET_MASK = 2;
var PMSG_INVALID_GATEWAY = 3;
var PMSG_INCORRECT_TCPIP_CONFIG = 4;
var PMSG_INVALID_UID = 5;
var PMSG_INVALID_PWD = 6;
var PMSG_INVALID_DNS1 = 7;
var PMSG_INVALID_DNS2 = 8;
var PMSG_INVALID_PORT_NUMBER = 9;
var PMSG_INVALID_BONJOUR_NAME = 10;

﻿var languageNum = new Array("en","sc","tc");
var item_name = new Array("D-LINK CORPORATION", "WIRELESS", "INTERNET CAMERA",
"LIVE VIDEO",
"Product", 
"Firmware version",
"step 3: Server Name Settings",
"Back",
"Next",
"Cancel",
"Camera Name",
"10 characters maximum",
""
);
var I_DINK_CORPORATION = 0;
var I_WIRELESS = 1;
var I_INTERNET_CAMERA = 2;
var I_LIVE_VIDEO = 3;
var I_PRODUCT = 4;
var I_FWVERSION = 5;
var I_TITLE = 6;
var I_BACK = 7;
var I_NEXT = 8;
var I_CANCEL = 9;
var I_CAMERA_NAME = 10;
var I_CAMERA_NAME_LENGTH_DES = 11;

var des_item_name = new Array (
"Copyright 2014, D-Link Corporation / D-Link Systems, Inc. All rights reserved.",
"D-Link recommends that you rename your camera for easy \
accessibility. Please assign a name of your choice before clicking \
on the <b>Next</b> button.<br><br>",
""
);

var D_COPYRIGHT = 0;
var D_TITLE_IFNO = 1;

var pop_msg = new Array (
"There was a problem with the request.",
"The format of Camera Name is invalid.",
""
);

var PMSG_REQUEST_FAILED = 0;
var PMSG_CAMERA_NAME_INVALID = 1;


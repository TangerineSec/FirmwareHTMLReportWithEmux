﻿var languageNum = new Array("en","sc","tc");
var item_name = new Array("D-LINK CORPORATION", "WIRELESS", "INTERNET CAMERA",
"LIVE VIDEO",
"Product", 
"Firmware version",
"step 5: Setup complete",
"Back",
"Apply",
"Cancel",
"IP Address",
"IP Camera Name",
"Time Zone",
"DDNS",
"DHCP Connection",
"PPPoE",
"Enable",
"Disable",
""
);
var I_DINK_CORPORATION = 0;
var I_WIRELESS = 1;
var I_INTERNET_CAMERA = 2;
var I_LIVE_VIDEO = 3;
var I_PRODUCT = 4;
var I_FWVERSION = 5;
var I_TITLE = 6;
var I_BACK = 7;
var I_NEXT = 8;
var I_CANCEL = 9;
var I_IP_ADDRESS = 10;
var I_CAMERA_NAME = 11;
var I_TIMEZONE = 12;
var I_DDNS = 13;
var I_DHCP = 14;
var I_PPPOE = 15;
var I_ENABLE = 16;
var I_DISABLE = 17;

var des_item_name = new Array (
"Copyright 2014, D-Link Corporation / D-Link Systems, Inc. All rights reserved.",
"Here is a summary of your camera settings. Click <b>Back</b> to \
modify the settings, or click <b>Apply</b> if all settings are \
correct. It is recommended you write down this information for \
future access or reference.<br><br>",
""
);

var D_COPYRIGHT = 0;
var D_TITLE_IFNO = 1;

var pop_msg = new Array (
"There was a problem with the request.",
""
);

var PMSG_REQUEST_FAILED = 0;


﻿var languageNum = new Array("en","sc","tc");
var item_name = new Array("D-Link Corporation", "SANS FIL", "CAMÉRA INTERNET",
"VIDÉO EN DIRECT",
"Nom d’utilisateur",
"Nouveau mot de passe",
"Ressaisir le mot de passe",
"Appliquer",
"Effacer",
"Quitter",
""
);
var I_DINK_CORPORATION = 0;
var I_WIRELESS = 1;
var I_INTERNET_CAMERA = 2;
var I_LIVE_VIDEO = 3;
var I_USER_NAME = 4;
var I_NEW_PWD = 5;
var I_RETYPE_PWD = 6;
var I_APPLY = 7;
var I_CLEAR = 8;
var I_EXIT = 9;

var pop_msg = new Array(
"Vous avez entré un mot de passe incorrect. Veuillez réessayer.",
"Le mot de passe n'a pas été correctement confirmé. Veuillez vous assurer que le nouveau mot de passe et le mot de passe ressaisi soient identiques.",
""
);

var P_PWD_INCORRECT = 0;
var P_PWD_RETYPE_INCORRECT = 1;

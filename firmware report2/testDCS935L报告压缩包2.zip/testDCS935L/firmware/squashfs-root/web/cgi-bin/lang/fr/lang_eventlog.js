﻿var languageNum = new Array("en","sc","tc");
var item_name = new Array("JOURNAL DES EVENEMENTS", "JOURNAL ACTUEL", "Actualiser",
"Actualiser",
""
);
var I_EVENT_LOG = 0;
var I_CURRENT_LOG = 1;
var I_REFRESH = 2;
var I_REFRESHING = 3;

var des_item_name = new Array (
"Le journal des événements journalise les événements de la caméra.",
"<b>Conseils utiles...</b><br><br>Vous pouvez actualiser le journal en cliquant sur le bouton Actualiser.",
""
);

var D_EVENT_LOG_INFO = 0;
var D_HELP_INFO = 1;

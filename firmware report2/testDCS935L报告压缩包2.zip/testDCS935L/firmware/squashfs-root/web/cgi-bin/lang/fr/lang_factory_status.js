﻿var languageNum = new Array("en","sc","tc");
var item_name = new Array("Restaurer les paramètres d’usine par défaut",
""
);
var I_RESTORE_FACTORY_DEFAULT = 0;

var des_item_name = new Array (
"Les paramètres par défaut de la caméra ont été restaurés.\
<br><br>La caméra redémarre. Elle peut prendre jusqu'à 60 secondes pour terminer ce processus.  \
<br><br>La connexion avec la caméra a été interrompue. Si la page Web de la caméra ne s'affiche pas automatiquement après \
le redémarrage, utilisez le logiciel de l'assistant de configuration fourni avec la caméra pour rechercher la caméra et vous y\
 connecter.<br><br>Veuillez patienter <SPAN ID=\"CountTime\"></SPAN> secondes...",
""
);

var D_FACTORY_INFO = 0;
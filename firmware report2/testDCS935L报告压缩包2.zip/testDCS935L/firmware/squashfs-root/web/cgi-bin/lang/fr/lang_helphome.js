﻿var languageNum = new Array("en","sc","tc");
var item_name = new Array("MENU ASSISTANCE", "Caméra",
""
);
var I_SUPPORT_MENU = 0;
var I_CAMERA = 1;

var des_item_name = new Array (
"<b>H.264</b> - Utilisez la diffusion H.264 pour voir la vidéo en direct de la caméra. Java doit être installé sur votre ordinateur pour \
utiliser H.264 afin de voir la vidéo en direct de la caméra. Si votre navigateur n'est pas IE, visitez le site \
<a href=\"http://www.java.com\">http://www.java.com</A> pour télécharger Java et l'installer.<br><br>",
"<b>MJPEG </b> - Utilisez la diffusion MJPEG pour voir la vidéo en direct de la caméra. \
Java doit être installé sur votre ordinateur pour utiliser MJPEG afin de voir la vidéo en direct de la caméra. \
Visitez le site <a href=\"http://www.java.com\">http://www.java.com</A> pour télécharger Java et l'installer.<br><br>",
"<b>Zoom</b> - Il s'agit d'un zoom numérique. Il vous permet d'agrandir les images jusqu'à 8 fois leur taille d'origine.<br><br>",
"<b>Marche/Arrêt audio</b> - Vous pouvez couper le son en appuyant sur le bouton Arrêt. Appuyez sur le bouton Marche pour réactiver l'écoute sonore.<br><br>",
"<b>Marche/Arrêt mode nuit</b> - Vous pouvez utiliser le bouton pour régler manuellement la fonction jour/nuit de la caméra. \
Pour pouvoir utiliser cette option, définissez d'abord le paramètre Mode jour/nuit sur manuel.<br><br>",
""
);

var D_H264 = 0;
var D_MJPEG = 1;
var D_ZOOM = 2;
var D_AUDIO = 3;
var D_NIGHT_MODE = 4;

﻿var languageNum = new Array("en","sc","tc");
var item_name = new Array("MENU ASSISTANCE", "Informations sur le dispositif", "Journal système",
"Journal des événements",
""
);
var I_SUPPORT_MENU = 0;
var I_DEVICE_INFO = 1;
var I_SYSTEM_LOG = 2;
var I_EVENT_LOG = 3;

var des_item_name = new Array (
"Cette page affiche toutes les informations disponibles sur les paramètres de la caméra et du réseau.",
"Afficher le fichier journal du système. Ce fichier donne toutes les informations utiles comme les messages de redémarrage du système.",
"Afficher le fichier journal des événements. Ce fichier donne toutes les informations utiles comme les messages de détection de mouvement.",
""
);

var D_DEVICE_INFO = 0;
var D_SYSTEM_LOG_INFO = 1;
var D_EVENT_LOG_INFO = 2;

﻿var languageNum = new Array("en","sc","tc");
var item_name = new Array("D-LINK CORPORATION", "SANS FIL", "CAMERA INTERNET",
"VIDÉO EN DIRECT",
"DECONNEXION",
"La déconnexion entraînera la fermeture du navigateur",
"Merci de fermer la page web manuellement",
"Déconnexion",
""
);
var I_DINK_CORPORATION = 0;
var I_WIRELESS = 1;
var I_INTERNET_CAMERA = 2;
var I_LIVE_VIDEO = 3;
var I_LOGOUT = 4;
var I_LOGOUT_CLICK_CLOSE_BROWSER = 5;
var I_LOGOUT_MANUALLY_CLOSE = 6;
var I_LOGOUT_2 = 7;

﻿var languageNum = new Array("en","sc","tc");
var item_name = new Array("Reboot the device",
""
);
var I_REBOOT_THE_DEVICE = 0;

var des_item_name = new Array (
"La caméra redémarre. Elle peut prendre jusqu'à 60 secondes pour terminer ce processus.\
<br><br>La connexion avec la caméra a été interrompue. Si la page Web de la caméra ne s'affiche pas automatiquement \
après le redémarrage, utilisez le logiciel de l'assistant de configuration fourni avec la caméra pour rechercher la caméra \
et vous y connecter.<br><br>Veuillez patienter <SPAN ID=\"CountTime\"></SPAN> secondes...",
""
);

var D_REBOOT_INFO = 0;
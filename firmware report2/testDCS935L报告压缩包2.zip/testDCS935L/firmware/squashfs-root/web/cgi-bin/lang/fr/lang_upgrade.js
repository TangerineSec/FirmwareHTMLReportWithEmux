﻿var languageNum = new Array("en","sc","tc");
var item_name = new Array("MiISE A JOUR DU MICROPROGRAMME", "INFORMATIONS SUR LE MICROPROGRAMME", "Version du microprogramme actuel : ",
"MiISE A JOUR DU MICROPROGRAMME",
"Chemin du fichier",
"télécharger",
""
);
var I_FIRMWARE_UPGRADE = 0;
var I_FIRMWARE_INFO = 1;
var I_CURRENT_FW_INFO = 2;
var I_FIRMWARE_UPGRADE_TITLE = 3;
var I_FILE_PATH = 4;
var I_UPLOAD = 5;

var des_item_name = new Array (
"Il est possible qu'une nouvelle mise à jour du microprogramme soit disponible pour la caméra. Il est recommandé de \
tenir le microprogramme de votre caméra à jour pour conserver et améliorer ses fonctions et ses performances.  \
Cliquez ici <A HREF='http://support.dlink.com/'><u>Page de support D-Link</u></A> pour rechercher la dernière version \
de microprogramme disponible.<br><br>Pour mettre à jour le microprogramme de la caméra IP, téléchargez la dernière version\
 disponible sur la page de support D-Link et enregistrez-la sur le disque dur local. Localisez le fichier sur votre disque \
 dur local en cliquant sur le bouton Parcourir. Une fois que vous avez localisé et ouvert le fichier à l'aide du bouton Parcourir, \
 cliquez sur le bouton <b>Télécharger</b> pour lancer la mise à jour du microprogramme.",
"<b>Conseils utiles...</b><br><br> Des mises à jour du microprogramme sont lancées régulièrement pour améliorer les fonctions de la \
caméra IP et ajouter des fonctions. Si vous rencontrez un problème avec une fonction particulière de la caméra IP, vérifiez notre site \
de support en cliquant <a href=\"http://support.dlink.com/\"><u>ici</u></A> pour voir si une mise à jour du microprogramme est disponible \
pour la caméra IP.",
""
);

var D_FWUP_INFO = 0;
var D_HELP_INFO = 1;

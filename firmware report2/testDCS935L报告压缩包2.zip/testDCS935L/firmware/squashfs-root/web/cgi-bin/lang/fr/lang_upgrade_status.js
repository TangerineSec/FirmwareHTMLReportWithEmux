﻿var languageNum = new Array("en","sc","tc");
var item_name = new Array("MISE A JOUR", "La mise à jour du microprogramme est terminée.", "Une mise à jour du microprogramme est en cours sur le périphérique.",
"Fichier non valide !",
"Une mise à jour du microprogramme est en cours sur le périphérique. Veuillez patienter pendant le déroulement de l'opération qui peut durer jusqu'à 240 secondes.",
"secondes",
""
);
var I_UPGRADE = 0;
var I_FIRMWARE_UPGRADE_OK = 1;
var I_FIRMWARE_IS_RUNNING = 2;
var I_FILE_INVALID = 3;
var I_WAIT_FW_RUNNING = 4;
var I_SEC = 5;

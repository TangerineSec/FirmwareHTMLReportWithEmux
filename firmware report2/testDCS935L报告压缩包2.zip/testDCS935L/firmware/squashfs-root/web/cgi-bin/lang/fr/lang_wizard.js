﻿var languageNum = new Array("en","sc","tc");
var item_name = new Array("PARAMÈTRES DE CONNEXION INTERNET", "Assistant de configuration de connexion Internet", "Configuration manuelle de la connexion Internet",
""
);
var I_INTERNET_CONNECTION_SETTING = 0;
var I_INTERNET_CONNECTION_SETUP = 1;
var I_MANAUAL_INTERNET_CONNECTION_SETUP = 2;

var des_item_name = new Array (
"Dans cette section, vous pouvez configurer les paramètres de l'interface réseau de la caméra IP. \
Si vous configurez le périphérique pour la première fois, D-Link vous recommande de cliquer sur le bouton \
Assistant de configuration de connexion Internet et de suivre les instructions qui s'affichent à l'écran. \
Si vous voulez modifier ou configurer manuellement les paramètres de la caméra IP, cliquez sur le bouton \
Configuration manuelle de la connexion Internet.",
"<b>Conseils utiles...</b><br><br>Si vous êtes un utilisateur expérimenté et que vous avez déjà configuré une caméra \
Internet par le passé, cliquez sur \'Configuration manuelle de  la connexion Internet\' afin de saisir manuellement la totalité des paramètres.",
""
);

var D_WIZARD_INFO = 0;
var D_HELP_INFO = 1;

var pop_msg = new Array (
"Un problème est survenu avec la requête.",
""
);

var PMSG_REQUEST_FAILED = 0;

﻿var languageNum = new Array("en","sc","tc");
var item_name = new Array("D-Link Corporation", "SANS FIL", "CAMÉRA INTERNET",
"VIDÉO EN DIRECT",
"Produit", 
"Version du microprogramme", 
"Bienvenue dans l'assistant de configuration de connexion Internet D-Link",
"Précédent",
"Suivant",
"Annuler",
""
);
var I_DINK_CORPORATION = 0;
var I_WIRELESS = 1;
var I_INTERNET_CAMERA = 2;
var I_LIVE_VIDEO = 3;
var I_PRODUCT = 4;
var I_FWVERSION = 5;
var I_TITLE = 6;
var I_BACK = 7;
var I_NEXT = 8;
var I_CANCEL = 9;

var des_item_name = new Array (
"Copyright 2014, D-Link Corporation / D-Link Systems, Inc. Tous droits réservés.",
"Cet assistant vous guidera étape par étape pour configurer votre nouvelle caméra D-Link et la connecter à Internet.<br><br>",
"<b>Étape 1 :</b> Configurer les paramètres du réseau local",
"<b>Étape 2 :</b> Configurer les paramètres DDNS",
"<b>Étape 3 :</b> Configurer le nom du serveur",
"<b>Étape 4 :</b> Configurer le fuseau horaire",
""
);

var D_COPYRIGHT = 0;
var D_TITLE_IFNO = 1;
var D_SETP1_INFO = 2;
var D_SETP2_INFO = 3;
var D_SETP3_INFO = 4;
var D_SETP4_INFO = 5;

﻿var languageNum = new Array("en","sc","tc");
var item_name = new Array("D-Link Corporation", "SANS FIL", "CAMÉRA INTERNET",
"VIDÉO EN DIRECT",
"Produit", 
"Version du microprogramme",
"Nom du serveur",
"Précédent",
"Suivant",
"Annuler",
"Nom caméra",
"10 caractères au maximum",
""
);
var I_DINK_CORPORATION = 0;
var I_WIRELESS = 1;
var I_INTERNET_CAMERA = 2;
var I_LIVE_VIDEO = 3;
var I_PRODUCT = 4;
var I_FWVERSION = 5;
var I_TITLE = 6;
var I_BACK = 7;
var I_NEXT = 8;
var I_CANCEL = 9;
var I_CAMERA_NAME = 10;
var I_CAMERA_NAME_LENGTH_DES = 11;

var des_item_name = new Array (
"Copyright 2014, D-Link Corporation / D-Link Systems, Inc. Tous droits réservés.",
"D-Link vous recommande de renommer la caméra pour des questions de simplicité d'accès. Choisissez\
 le nom que vous préférez, puis cliquez sur le bouton <b>Suivant</b>.<br><br>",
""
);

var D_COPYRIGHT = 0;
var D_TITLE_IFNO = 1;

var pop_msg = new Array (
"Un problème est survenu avec la requête.",
"Le format du nom de la caméra est incorrect.",
""
);

var PMSG_REQUEST_FAILED = 0;
var PMSG_CAMERA_NAME_INVALID = 1;


﻿var languageNum = new Array("en","sc","tc");
var item_name = new Array("D-Link Corporation", "SANS FIL", "CAMÉRA INTERNET",
"VIDÉO EN DIRECT",
"Produit", 
"Version du microprogramme",
"Étape 5 : Configuration terminée",
"Précédent",
"Appliquer",
"Annuler",
"Adresse IP",
"Nom caméra IP",
"Fuseau horaire",
"DDNS",
"Connexion DHCP",
"PPPoE",
"Activer",
"Désactiver",
""
);
var I_DINK_CORPORATION = 0;
var I_WIRELESS = 1;
var I_INTERNET_CAMERA = 2;
var I_LIVE_VIDEO = 3;
var I_PRODUCT = 4;
var I_FWVERSION = 5;
var I_TITLE = 6;
var I_BACK = 7;
var I_NEXT = 8;
var I_CANCEL = 9;
var I_IP_ADDRESS = 10;
var I_CAMERA_NAME = 11;
var I_TIMEZONE = 12;
var I_DDNS = 13;
var I_DHCP = 14;
var I_PPPOE = 15;
var I_ENABLE = 16;
var I_DISABLE = 17;

var des_item_name = new Array (
"Copyright 2014, D-Link Corporation / D-Link Systems, Inc. Tous droits réservés.",
"Cette page affiche un récapitulatif des paramètres de la caméra. Cliquez sur <b>Précédent</b> pour modifier les paramètres ou cliquez sur <b>Appliquer</b>\
 si tous les paramètres sont corrects. Il est recommandé de noter ces informations pour tout \
 accès ou référence ultérieure.<br><br>",
""
);

var D_COPYRIGHT = 0;
var D_TITLE_IFNO = 1;

var pop_msg = new Array (
"Un problème est survenu avec la requête.",
""
);

var PMSG_REQUEST_FAILED = 0;


﻿var languageNum = new Array("en","sc","tc");
var item_name = new Array("D-Link Corporation", "Wireless", "INTERNET CAMERA",
"Live Video",
"Nome utente",
"Nuova password",
"Digita nuovamente password",
"Applica",
"Cancella",
"Esci",
""
);
var I_DINK_CORPORATION = 0;
var I_WIRELESS = 1;
var I_INTERNET_CAMERA = 2;
var I_LIVE_VIDEO = 3;
var I_USER_NAME = 4;
var I_NEW_PWD = 5;
var I_RETYPE_PWD = 6;
var I_APPLY = 7;
var I_CLEAR = 8;
var I_EXIT = 9;

var pop_msg = new Array(
"La password immessa non è corretta. Riprovare.",
"La password non è stata confermata correttamente. Verificare che la nuova password e la password di verifica siano identiche.",
""
);

var P_PWD_INCORRECT = 0;
var P_PWD_RETYPE_INCORRECT = 1;

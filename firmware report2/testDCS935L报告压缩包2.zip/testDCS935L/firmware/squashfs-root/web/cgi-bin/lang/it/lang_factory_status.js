﻿var languageNum = new Array("en","sc","tc");
var item_name = new Array("Ripristina le impostazioni di fabbrica",
""
);
var I_RESTORE_FACTORY_DEFAULT = 0;

var des_item_name = new Array (
"Sono state ripristinate le impostazioni predefinite della videocamera.<br><br>\
La videocamera verrà riavviata. L'operazione può richiedere fino a 60 secondi.  <br><br>\
La connessione con la videocamera è stata interrotta. Se la pagina Web della videocamera  non viene visualizzata \
automaticamente dopo il riavvio, utilizzare la Configurazione guidata \
fornita con la videocamera per cercare la videocamera e connettersi ad essa.<br><br>\
Attendere <SPAN ID=\"CountTime\"></SPAN> secondi...",
""
);

var D_FACTORY_INFO = 0;
﻿var languageNum = new Array("en","sc","tc");
var item_name = new Array("MENU SUPPORTO", "videocamera",
""
);
var I_SUPPORT_MENU = 0;
var I_CAMERA = 1;

var des_item_name = new Array (
"<b>H.264</b>: Consente di utilizzare lo streaming H.264 per visualizzare il video in diretta della videocamera. Per poter visualizzare il video in diretta della videocamera tramite H.264, nel computer in uso deve essere installato Java. Se il browser utilizzato non è Internet Explorer, \
visitare la pagina all'indirizzo <a href=\"http://www.java.com\">http://www.java.com</A> per scaricare e installare Java.<br><br>",
"<b>MJPEG </b>: Consente di utilizzare lo streaming MJPEG per visualizzare il video in diretta della videocamera. \
Per poter visualizzare il video in diretta della videocamera tramite MJPEG, nel computer in uso deve essere installato Java. \
Visitare la pagina all'indirizzo <a href=\"http://www.java.com\">http://www.java.com</A> per scaricare e installare Java.<br><br>",
"<b>Zoom</b>: è uno zoom digitale. Consente di ingrandire le immagini fino a 8 volte.<br><br>",
"<b>On/Off audio</b>: è possibile silenziare l'audio premendo il pulsante Off. Premere il pulsante On per controllare di nuovo l'audio.<br><br>",
"<b>Attiva/Disattiva modalità notturna</b>: è possibile utilizzare il pulsante per impostare manualmente la modalità diurna/notturna per la videocamera. \
Per utilizzare questa opzione, è prima necessario impostare la modalità diurn/notturna su Manuale.<br><br>",
""
);

var D_H264 = 0;
var D_MJPEG = 1;
var D_ZOOM = 2;
var D_AUDIO = 3;
var D_NIGHT_MODE = 4;

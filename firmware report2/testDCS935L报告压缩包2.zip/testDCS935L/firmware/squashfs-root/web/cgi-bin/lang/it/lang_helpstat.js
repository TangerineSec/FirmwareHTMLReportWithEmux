﻿var languageNum = new Array("en","sc","tc");
var item_name = new Array("MENU SUPPORTO", "Informazioni sul dispositivo", "Registro di sistema",
"Registro degli eventi",
""
);
var I_SUPPORT_MENU = 0;
var I_DEVICE_INFO = 1;
var I_SYSTEM_LOG = 2;
var I_EVENT_LOG = 3;

var des_item_name = new Array (
"Questa pagina visualizza tutte le informazioni relative alla videocamera e alle impostazioni di rete.",
"Visualizza il file di registro del sistema. Questo file mostra tutte le informazioni utili, ad esempio i messaggi di riavvio del sistema.",
"Visualizza il file del log eventi. Questo file mostra tutte le informazioni utili, ad esempio i messaggi di rilevamento del movimento.",
""
);

var D_DEVICE_INFO = 0;
var D_SYSTEM_LOG_INFO = 1;
var D_EVENT_LOG_INFO = 2;

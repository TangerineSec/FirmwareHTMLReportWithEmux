﻿var languageNum = new Array("en","sc","tc");
var item_name = new Array("Reboot the device",
""
);
var I_REBOOT_THE_DEVICE = 0;

var des_item_name = new Array (
"La videocamera verrà riavviata. L'operazione può richiedere fino a 60 secondi.<br><br>\
La connessione con la videocamera è stata interrotta. Se la pagina Web della videocamera  non viene visualizzata \
automaticamente dopo il riavvio, utilizzare la Configurazione guidata \
fornita con la videocamera per cercare la videocamera e connettersi ad essa.<br><br>\
Attendere <SPAN ID=\"CountTime\"></SPAN> secondi...",
""
);

var D_REBOOT_INFO = 0;
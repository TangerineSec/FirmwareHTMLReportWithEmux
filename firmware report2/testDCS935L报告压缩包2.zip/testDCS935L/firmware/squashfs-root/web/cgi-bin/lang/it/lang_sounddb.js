﻿var languageNum = new Array("en","sc","tc");
var item_name = new Array("Salva impostazioni", "Non salvare impostazioni", "Salva",
"Sound Detection", 
"Configurazione Sound Detection",
"Sound Detection",
"Attiva",
"Disattiva",
"Detection Level",
"dB",
""
);

var I_SAVE_SETTING = 0;
var I_NOT_SAVE_SETTING = 1;
var I_SAVING = 2;
var I_SOUND_DETECTION = 3;
var I_SOUND_DETECTION_SETTING = 4;
var I_SOUND_DETECTION_ITEM = 5;
var I_ENABLE = 6;
var I_DISABLE = 7;
var I_LEVEL = 8;
var I_DB = 9;

var des_item_name = new Array (
"In questa sezione è possibile configurare le impostazioni del \
rilevamento del suono per la videocamera.<br><br>\
Si noti che per poter visualizzare la finestra dB/Durata per i suoni, è necessario che nel computer sia installato Java. Se non viene visualizzata la \
finestra dB/Durata per i suoni, visitare il sito <a href=\"http://www.java.com\">\
http://www.java.com</A> per scaricare e installare Java.",
"Il microfono è disabilitato. Abilitarlo.",
""
);

var D_TITLE_INFO = 0;
var D_MICROPHONE_DISABLED = 1;

var pop_msg = new Array (
"Si è verificato un problema relativo alla richiesta.",
""
);

var PMSG_REQUEST_FAILED = 0;

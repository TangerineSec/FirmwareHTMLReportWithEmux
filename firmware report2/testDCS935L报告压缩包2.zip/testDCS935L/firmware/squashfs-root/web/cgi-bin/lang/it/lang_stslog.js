﻿var languageNum = new Array("en","sc","tc");
var item_name = new Array("Registro di sistema", "REGISTRO ATTUALE", "Aggiorna",
"Aggiorna",
""
);
var I_SYSTEM_LOG = 0;
var I_CURRENT_LOG = 1;
var I_REFRESH = 2;
var I_REFRESHING = 3;

var des_item_name = new Array (
"Il file di log di sistema registra gli eventi di sistema che si sono verificati.",
"<b>Suggerimenti utili...</b><br><br>È possibile aggiornare il log facendo clic sul pulsante Aggiorna.",
""
);

var D_SYSTEM_LOG_INFO = 0;
var D_HELP_INFO = 1;

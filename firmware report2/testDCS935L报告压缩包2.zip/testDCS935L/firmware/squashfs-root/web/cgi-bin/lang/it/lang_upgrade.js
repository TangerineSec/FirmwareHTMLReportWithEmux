﻿var languageNum = new Array("en","sc","tc");
var item_name = new Array("Aggiornamento firmware", "INFORMAZIONI FIRMWARE", "Versione corrente firmware:",
"Aggiornamento firmware",
"Percorso del file:",
"Percorso di caricamento del file",
""
);
var I_FIRMWARE_UPGRADE = 0;
var I_FIRMWARE_INFO = 1;
var I_CURRENT_FW_INFO = 2;
var I_FIRMWARE_UPGRADE_TITLE = 3;
var I_FILE_PATH = 4;
var I_UPLOAD = 5;

var des_item_name = new Array (
"Potrebbe essere disponibile un nuovo aggiornamento del firmware per la videocamera. Si consiglia di mantenere aggiornato il firmware della videocamera \
per garantire e migliorare le prestazioni e le funzionalità.  Fare clic sulla \
<A HREF='http://support.dlink.com/'><u>Pagina del supporto tecnico D-Link</u></A> per verificare la disponibilità \
della versione più recente del firmware.<br><br>Per aggiornare il firmware della videocamera IP, scaricare la versione più recente \
del firmware dalla pagina del supporto tecnico D-Link e salvarla sul disco rigido locale. Per individuare il file sul disco rigido locale, fare \
clic sul pulsante Sfoglia. Dopo aver individuato e aperto il file con il pulsante Sfoglia, fare clic sul pulsante <b>Carica</b> per avviare l'aggiornamento del firmware.",
"<b>Suggerimenti utili...</b><br><br> \
Periodicamente vengono rilasciati aggiornamenti del firmware che consentono di ottimizzare il funzionamento della \
videocamera IP e di aggiungere nuove funzionalità. In caso di problemi con una funzionalità specifica della videocamera IP, visitare il sito di assistenza tecnica facendo clic \
<a href=\"http://support.dlink.com/\"><u>qui</u></A> per verificare se per la videocamera IP è disponibile firmware aggiornato.",
""
);

var D_FWUP_INFO = 0;
var D_HELP_INFO = 1;

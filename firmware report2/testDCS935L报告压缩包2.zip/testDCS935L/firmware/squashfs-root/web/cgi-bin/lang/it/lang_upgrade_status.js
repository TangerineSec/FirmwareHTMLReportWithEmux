﻿var languageNum = new Array("en","sc","tc");
var item_name = new Array("Percorso di caricamento del file", "Aggiornamento del firmware completato.", "Nel dispositivo verrà ora eseguito un aggiornamento del firmware.",
"File non valido!",
"Nel dispositivo verrà ora eseguito un aggiornamento del firmware. Attendere. L'operazione può richiedere fino a 240 secondi.",
"secondi",
""
);
var I_UPGRADE = 0;
var I_FIRMWARE_UPGRADE_OK = 1;
var I_FIRMWARE_IS_RUNNING = 2;
var I_FILE_INVALID = 3;
var I_WAIT_FW_RUNNING = 4;
var I_SEC = 5;

﻿var languageNum = new Array("en","sc","tc");
var item_name = new Array("IMPOSTAZIONI DI CONNESSIONE A INTERNET", "Configurazione guidata connessione Internet", "Configurazione manuale connessione Internet",
""
);
var I_INTERNET_CONNECTION_SETTING = 0;
var I_INTERNET_CONNECTION_SETUP = 1;
var I_MANAUAL_INTERNET_CONNECTION_SETUP = 2;

var des_item_name = new Array (
"In questa sezione è possibile configurare le impostazioni dell'interfaccia di rete della videocamera IP. \
Se si sta configurando il dispositivo per la prima volta, D-Link consiglia \
di fare clic sul pulsante Configurazione guidata connessione Internet e di seguire \
le istruzioni visualizzate. Per modificare o configurare manualmente le impostazioni della videocamera \
IP, fare clic sul pulsante Configurazione manuale connessione \
Internet.",
"<b>Suggerimenti utili...</b><br><br>Gli utenti esperti che hanno già configurato una videocamera Internet \
prima, possono fare clic su 'Configurazione manuale connessione Internet'per inserire manualmente \
tutte le impostazioni.",
""
);

var D_WIZARD_INFO = 0;
var D_HELP_INFO = 1;

var pop_msg = new Array (
"Si è verificato un problema relativo alla richiesta.",
""
);

var PMSG_REQUEST_FAILED = 0;

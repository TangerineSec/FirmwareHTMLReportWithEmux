﻿var languageNum = new Array("en","sc","tc");
var item_name = new Array("D-Link Corporation", "Wireless", "INTERNET CAMERA",
"Live Video",
"Prodotto", 
"Versione firmware", 
"Benvenuto nella configurazione guidata di D-Link: configurazione della connessione a Internet",
"Indietro",
"Annulla",
"Annulla",
""
);
var I_DINK_CORPORATION = 0;
var I_WIRELESS = 1;
var I_INTERNET_CAMERA = 2;
var I_LIVE_VIDEO = 3;
var I_PRODUCT = 4;
var I_FWVERSION = 5;
var I_TITLE = 6;
var I_BACK = 7;
var I_NEXT = 8;
var I_CANCEL = 9;

var des_item_name = new Array (
"Copyright 2014, D-Link Corporation / D-Link Systems, Inc. Tutti i diritti riservati.",
"Questa procedura guidata assiste l'utente nelle varie \
fasi di configurazione e connessione della videocamera D-Link \
a Internet.<br><br>",
"<b>Passaggio 1:</b> impostazioni LAN",
"<b>Passaggio 2:</b> impostazioni DDNS",
"<b>Passaggio 3:</b> impostazioni Nome server",
"<b>Passaggio 4:</b> impostazioni fuso orario",
""
);

var D_COPYRIGHT = 0;
var D_TITLE_IFNO = 1;
var D_SETP1_INFO = 2;
var D_SETP2_INFO = 3;
var D_SETP3_INFO = 4;
var D_SETP4_INFO = 5;

﻿var languageNum = new Array("en","sc","tc");
var item_name = new Array("D-Link Corporation", "Wireless", "INTERNET CAMERA",
"Live Video",
"Prodotto", 
"Versione firmware",
"Nome server",
"Indietro",
"Avanti",
"Cancella",
"IP Camera Name",
"{$10} caratteri al massimo",
""
);
var I_DINK_CORPORATION = 0;
var I_WIRELESS = 1;
var I_INTERNET_CAMERA = 2;
var I_LIVE_VIDEO = 3;
var I_PRODUCT = 4;
var I_FWVERSION = 5;
var I_TITLE = 6;
var I_BACK = 7;
var I_NEXT = 8;
var I_CANCEL = 9;
var I_CAMERA_NAME = 10;
var I_CAMERA_NAME_LENGTH_DES = 11;

var des_item_name = new Array (
"Copyright 2014, D-Link Corporation / D-Link Systems, Inc. Tutti i diritti riservati.",
"D-Link raccomanda di rinominare la videocamera per \
una facile accessibilità. Assegnare un nome di propria scelta prima di fare \
clic sul pulsante <b>Avanti</b>.<br><br>",
""
);

var D_COPYRIGHT = 0;
var D_TITLE_IFNO = 1;

var pop_msg = new Array (
"Si è verificato un problema relativo alla richiesta.",
"Il formato di Nome videocamera non è valido.",
""
);

var PMSG_REQUEST_FAILED = 0;
var PMSG_CAMERA_NAME_INVALID = 1;


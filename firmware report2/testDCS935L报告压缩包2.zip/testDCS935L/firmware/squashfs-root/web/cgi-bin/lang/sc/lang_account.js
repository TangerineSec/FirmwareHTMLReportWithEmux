﻿var languageNum = new Array("en","sc","tc");
var item_name = new Array("D-LINK公司", "无线", "网络摄像机",
"实时视频",
"用户名",
"新密码",
"再次输入密码",
"应用",
"清除",
"退出",
""
);
var I_DINK_CORPORATION = 0;
var I_WIRELESS = 1;
var I_INTERNET_CAMERA = 2;
var I_LIVE_VIDEO = 3;
var I_USER_NAME = 4;
var I_NEW_PWD = 5;
var I_RETYPE_PWD = 6;
var I_APPLY = 7;
var I_CLEAR = 8;
var I_EXIT = 9;

var pop_msg = new Array(
"您输入了一个错误的密码。请再次尝试。",
"没有正确确认密码。请确认新密码，然后重新键入密码匹配验证。",
""
);

var P_PWD_INCORRECT = 0;
var P_PWD_RETYPE_INCORRECT = 1;

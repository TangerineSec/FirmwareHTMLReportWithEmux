﻿var languageNum = new Array("en","sc","tc");
var item_name = new Array("站点搜索", "刷新", "选择",
"退出", 
"加入",
"SSID",
"BSSID",
"信道",
"加密",
"信号 %",
"搜索中",
"Ad-Hoc",
"Infrastructure",
"Automatic",
"无",
"WEP",
"WPA-PSK",
"WPA2-PSK",
"WPA-PSK/WPA2-PSK",
""
);

var I_SITE_SURVEY = 0;
var I_REFRESH = 1;
var I_SELECT = 2;
var I_EXIT = 3;
var I_JOIN = 4;
var I_SSID = 5;
var I_BSSID = 6;
var I_CHANNEL = 7;
var I_ENCRYPTION = 8;
var I_SIGNAL = 9;
var I_SEARCHING = 10;
var I_ADHOC = 11;
var I_INFRASTRUCTURE = 12;
var I_AUTOMATIC = 13;
var I_NO = 14;
var I_WEP = 15;
var I_WPAPSK = 16;
var I_WPA2PSK = 17;
var I_WPAWPA2PSK = 18;

var des_item_name = new Array (
"该功能可以扫描并显示您的设备周围所有可用的无线网络。您可以点击 <b>刷新</b> 来重新扫描并搜索可用的无线网络。 \
选中该按钮，查看想要接入的无线网络，然后点击 <b>选择</b> 执行。",
""
);

var D_TITLE_INFO = 0;

var pop_msg = new Array (
"請求失敗",
""
);

var PMSG_REQUEST_FAILED = 0;

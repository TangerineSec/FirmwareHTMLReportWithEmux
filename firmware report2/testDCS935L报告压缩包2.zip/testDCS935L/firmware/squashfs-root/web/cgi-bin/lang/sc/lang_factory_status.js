﻿var languageNum = new Array("en","sc","tc");
var item_name = new Array("恢复到出厂默认设置",
""
);
var I_RESTORE_FACTORY_DEFAULT = 0;

var des_item_name = new Array (
"摄像机已被重置为出厂设置。<br><br>\
摄像机正在重新启动，它可能需要最多60秒重新启动。<br><br>\
与摄像机的连接已被切断。如果摄像机的网页在重启后无法自动显示，请使用安装向导软件搜索并连接到摄像机提供。<br><br>\
请等待&nbsp;<SPAN ID=\"CountTime\"></SPAN>&nbsp;秒…<br><br>",
""
);

var D_FACTORY_INFO = 0;
﻿var languageNum = new Array("en","sc","tc");
var item_name = new Array("支持菜单", "设备信息", "系统日志",
"事件日志",
""
);
var I_SUPPORT_MENU = 0;
var I_DEVICE_INFO = 1;
var I_SYSTEM_LOG = 2;
var I_EVENT_LOG = 3;

var des_item_name = new Array (
"该页面显示关于摄像机和网络设置的所有信息。",
"查看系统日志文件。此文件显示所有有用的信息，如系统重启信息。",
"查看事件日志文件。此文件显示所有有用的信息，如移动侦测通知。",
""
);

var D_DEVICE_INFO = 0;
var D_SYSTEM_LOG_INFO = 1;
var D_EVENT_LOG_INFO = 2;

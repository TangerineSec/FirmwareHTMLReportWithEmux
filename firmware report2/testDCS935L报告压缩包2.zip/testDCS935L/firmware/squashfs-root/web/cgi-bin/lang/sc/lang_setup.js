﻿var languageNum = new Array("en","sc","tc");
var item_name = new Array("D-LINK公司", "无线", "网络摄像机",
"实时视频",
"产品", 
"固件版本", 
"实时视频",
"设置",
"维护",
"状态",
"帮助",
"设置向导",
"网络设置",
"无线设置",
"扩展设置",
"动态DNS",
"IP 过滤器",
"图像设置",
"音频和视频",
"隱私遮罩",
"动作探测",
"声音侦测",
"邮件",
"FTP",
"快照",
"视频剪辑",
"SD卡录制",
"SD卡管理",
"时间和日期",
"日/夜模式",
"摄像机控制",
"登出",
"管理员",
"系统",
"固件升级",
"设备信息",
"系统日志",
"事件日志",
"菜单",
""
);
var I_DINK_CORPORATION = 0;
var I_WIRELESS = 1;
var I_INTERNET_CAMERA = 2;
var I_LIVE_VIDEO = 3;
var I_PRODUCT = 4;
var I_FWVERSION = 5;
var I_LIVE_VIDEO_2 = 6;
var I_SETUP = 7;
var I_MAINTENANCE = 8;
var I_STATUS = 9;
var I_HELP = 10;
var I_WIZARD = 11;
var I_NETWORK_SETUP = 12;
var I_WIRELESS_SETUP = 13;
var I_EXTENDER_SETUP = 14;
var I_DDNS = 15;
var I_IPFILTER = 16;
var I_IMAGE_SETUP = 17;
var I_AUDIO_VIDEO_SETUP = 18;
var I_PRIVACY_MASK = 19;
var I_MOTION_DETECTION = 20;
var I_SOUND_DETECTION = 21;
var I_MAIL = 22;
var I_FTP = 23;
var I_SNAPSHOT = 24;
var I_VIDEO_CLIP = 25;
var I_SD_RECORDING = 26;
var I_SD_MANAGEMENT = 27;
var I_TIME_AND_DATE = 28;
var I_DAY_NIGHT_MODE = 29;
var I_CAMERA_CONTROL = 30;
var I_LOGOUT = 31;
var I_ADMIN = 32;
var I_SYSTEM = 33;
var I_FW_UP = 34;
var I_DEVICE_INFO = 35;
var I_SYSTEM_LOG = 36;
var I_EVENT_LOG = 37;
var I_MENU = 38;

var des_item_name = new Array (
"Copyright 2014，D-Link Corporation/D-Link Systems, Inc。版权所有。",
""
);

var D_COPYRIGHT = 0;

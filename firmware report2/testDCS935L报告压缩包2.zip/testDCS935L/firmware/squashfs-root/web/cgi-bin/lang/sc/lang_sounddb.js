﻿var languageNum = new Array("en","sc","tc");
var item_name = new Array("保存设置", "不保存设置", "保存",
"声音侦测", 
"声音侦测设置",
"声音侦测",
"启用",
"禁用",
"侦测级别",
"dB",
""
);

var I_SAVE_SETTING = 0;
var I_NOT_SAVE_SETTING = 1;
var I_SAVING = 2;
var I_SOUND_DETECTION = 3;
var I_SOUND_DETECTION_SETTING = 4;
var I_SOUND_DETECTION_ITEM = 5;
var I_ENABLE = 6;
var I_DISABLE = 7;
var I_LEVEL = 8;
var I_DB = 9;

var des_item_name = new Array (
"在此节，您可以为您的摄像机进行声音侦测设置。\
<br><br>请注意：您的电脑需要安装Java程序，以查看声音的dB/时间页面。 如果您在下面没有看到声音dB/时间页面， \
请至<a href=\"http://www.java.com\">http://www.java.com</A>下载并安装Java程序。",
"麦克风被禁用，请启用麦克风。",
""
);

var D_TITLE_INFO = 0;
var D_MICROPHONE_DISABLED = 1;

var pop_msg = new Array (
"請求失敗",
""
);

var PMSG_REQUEST_FAILED = 0;

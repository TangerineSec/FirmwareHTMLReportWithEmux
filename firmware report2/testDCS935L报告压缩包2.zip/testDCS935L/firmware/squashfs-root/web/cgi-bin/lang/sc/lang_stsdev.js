﻿var languageNum = new Array("en","sc","tc");
var item_name = new Array("设备信息", "基本信息", "摄像机名",
"时间和日期",
"固件版本",
"代理版本",
"MAC地址",
"IP地址",
"子网掩码",
"默认网关",
"首选DNS",
"备选DNS",
"动态DNS",
"UPnP端口转发",
"无线状态",
"连接模式",
"链接",
"SSID",
"信道",
"加密",
"刷新",
"启用",
"禁用",
"Infrastructure",
"Ad-Hoc",
"是",
"否",
"无",
"WEP",
"WPA-PSK",
"WPA2-PSK",
"刷新中",
"PPPoE 状态",
"已连接",
"连接失败",
"硬件版本",
""
);
var I_DEVICE_INFO = 0;
var I_BASIC_INFORMATION = 1;
var I_CAMERA_NAME = 2;
var I_TIME_AND_DATE = 3;
var I_FWVERSION = 4;
var I_AGENT_VERSION = 5;
var I_MAC_ADDRESS = 6;
var I_IP_ADDRESS = 7;
var I_SUBNET_MASK = 8;
var I_DEFAULT_GATEWAY = 9;
var I_PRIMARY_DNS = 10;
var I_SECONDARY_DNS = 11;
var I_DDNS = 12;
var I_UPNP_PORT_FORWARDING = 13;
var I_WIRELESS_STATUS = 14;
var I_CONNECTION_MODE = 15;
var I_LINK = 16;
var I_SSID = 17;
var I_CHANNEL = 18;
var I_ENCRYPTION = 19;
var I_REFRESH = 20;
var I_ENABLE = 21;
var I_DISABLE = 22;
var I_INFRASTRUCTURE = 23;
var I_ADHOC = 24;
var I_YES = 25;
var I_NO = 26;
var I_NONE = 27;
var I_WEP = 28;
var I_WPAPSK = 29;
var I_WPA2PSK = 30;
var I_REFRESHING = 31;
var I_PPPOE_STATUS = 32;
var I_PPPOE_CONNECT_SUCCESS = 33;
var I_PPPOE_CONNECT_FAIL = 34;
var I_HWVERSION = 35;

var des_item_name = new Array (
"此页显示所有的网络连接详细信息。 此处也显示了固件版本。",
"<b>帮助提示..</b><br><br>此页显示所有的网络连接详细信息。",
""
);

var D_DEVICE_INFO = 0;
var D_HELP_INFO = 1;

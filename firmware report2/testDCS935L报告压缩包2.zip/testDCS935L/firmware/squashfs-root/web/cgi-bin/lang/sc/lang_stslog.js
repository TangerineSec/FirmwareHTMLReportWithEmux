﻿var languageNum = new Array("en","sc","tc");
var item_name = new Array("系统日志", "当前日志", "刷新",
"刷新中",
""
);
var I_SYSTEM_LOG = 0;
var I_CURRENT_LOG = 1;
var I_REFRESH = 2;
var I_REFRESHING = 3;

var des_item_name = new Array (
"系统日志记录发生的摄像机系统事件。",
"<b>帮助提示..</b><br><br>您可以单击刷新按钮来刷新日志。",
""
);

var D_SYSTEM_LOG_INFO = 0;
var D_HELP_INFO = 1;

﻿var languageNum = new Array("en","sc","tc");
var item_name = new Array("支持菜单", "实时视频", "设置",
"维护",
"状态",
"摄像机",
"设置向导",
"网络设置",
"无线设置",
"扩展设置",
"动态DNS",
"IP 过滤器",
"图像设置",
"音频和视频",
"隱私遮罩",
"动作探测",
"声音侦测",
"邮件",
"FTP",
"快照",
"视频剪辑",
"时间和日期",
"日/夜模式",
"管理员",
"系统",
"固件升级",
"设备信息",
"系统日志",
"事件日志",
"SD卡管理",
""
);
var I_SUPPORT_MENU = 0;
var I_LIVE_VIDEO = 1;
var I_SETUP = 2;
var I_MAINTENANCE = 3;
var I_STATUS = 4;
var I_CAMERA = 5;
var I_WIZARD = 6;
var I_NETWORK_SETUP = 7;
var I_WIRELESS_SETUP = 8;
var I_EXTENDER_SETUP = 9;
var I_DYNAMIC_DNS = 10;
var I_IPFILTER = 11;
var I_IMAGE_SETUP = 12;
var I_AUDIO_AND_VIDEO = 13
var I_PRIVACY_MASK = 14;
var I_MOTION_DETECTION = 15;
var I_SOUND_DETECTION = 16;
var I_MAIL = 17;
var I_FTP = 18;
var I_SNAPSHOT = 19;
var I_VIDEO_CLIP = 20;
var I_TIME_AND_DATE = 21;
var I_DAY_NIGHT_MODE = 22;
var I_ADMIN = 23;
var I_SYSTEM = 24;
var I_FIRMWARE_UPGRADE = 25;
var I_DEVICE_INFO = 26;
var I_SYSTEM_LOG = 27;
var I_EVENT_LOG = 28;
var I_SD_MANAGEMENT = 29;
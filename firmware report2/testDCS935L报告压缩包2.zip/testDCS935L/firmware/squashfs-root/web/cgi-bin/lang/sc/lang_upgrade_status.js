﻿var languageNum = new Array("en","sc","tc");
var item_name = new Array("升级", "固件升级完成。", "固件升级在设备上正在运行。",
"无效文件！",
"固件升级在设备上正在运行，请等待，可能会需要240秒完成此过程。",
"秒",
""
);
var I_UPGRADE = 0;
var I_FIRMWARE_UPGRADE_OK = 1;
var I_FIRMWARE_IS_RUNNING = 2;
var I_FILE_INVALID = 3;
var I_WAIT_FW_RUNNING = 4;
var I_SEC = 5;

﻿var languageNum = new Array("en","sc","tc");
var item_name = new Array("Internet连接设置", "Internet连接设置向导", "手动Internet连接设置",
""
);
var I_INTERNET_CONNECTION_SETTING = 0;
var I_INTERNET_CONNECTION_SETUP = 1;
var I_MANAUAL_INTERNET_CONNECTION_SETUP = 2;

var des_item_name = new Array (
"在本章节中，您可以配置IP摄像机的网络接口设置。\
如果您是首次配置设备，D-Link建议您单击 <b>Internet连接设置向导</b> 按钮并按照界面说明操作。\
如果您要手动修改或配置IP摄像机，请单击 <b>手动Internet连接设置</b> 按钮。<br><br>",
"<b>帮助提示..</b><br><br>如果您是高级用户，并且曾经配置过网络摄像机，请点击 <b>手动Internet连接设置</b> ，手动输入所有设置。",
""
);

var D_WIZARD_INFO = 0;
var D_HELP_INFO = 1;

var pop_msg = new Array (
"请求失败",
""
);

var PMSG_REQUEST_FAILED = 0;

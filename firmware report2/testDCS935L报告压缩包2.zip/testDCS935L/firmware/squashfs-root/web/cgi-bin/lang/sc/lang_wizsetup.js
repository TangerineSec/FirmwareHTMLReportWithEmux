﻿var languageNum = new Array("en","sc","tc");
var item_name = new Array("D-LINK公司", "无线", "网络摄像机",
"实时视频",
"产品", 
"固件版本",
"欢迎使用D-Link设置向导-Internet连接设置",
"返回",
"下一步",
"取消",
""
);
var I_DINK_CORPORATION = 0;
var I_WIRELESS = 1;
var I_INTERNET_CAMERA = 2;
var I_LIVE_VIDEO = 3;
var I_PRODUCT = 4;
var I_FWVERSION = 5;
var I_TITLE = 6;
var I_BACK = 7;
var I_NEXT = 8;
var I_CANCEL = 9;

var des_item_name = new Array (
"Copyright 2014，D-Link Corporation/D-Link Systems, Inc。版权所有。",
"该向导将指导您一步一步地配置您的D-Link摄像机，并将摄像机连接到Internet上。<br><br>",
"<b>第一步:</b> 设置LAN配置",
"<b>第二步:</b> 设置动态DNS配置",
"<b>第三步:</b> 服务器名配置",
"<b>第四步:</b> 设置时区",
""
);

var D_COPYRIGHT = 0;
var D_TITLE_IFNO = 1;
var D_SETP1_INFO = 2;
var D_SETP2_INFO = 3;
var D_SETP3_INFO = 4;
var D_SETP4_INFO = 5;

﻿var languageNum = new Array("en","sc","tc");
var item_name = new Array("D-LINK公司", "无线", "网络摄像机",
"实时视频",
"产品", 
"固件版本",
"第二步：设置动态DNS配置",
"返回",
"下一步",
"取消",
"动态DNS启用",
"服务器地址",
"主机名",
"用户名",
"密码",
"超时",
"小时",
""
);
var I_DINK_CORPORATION = 0;
var I_WIRELESS = 1;
var I_INTERNET_CAMERA = 2;
var I_LIVE_VIDEO = 3;
var I_PRODUCT = 4;
var I_FWVERSION = 5;
var I_TITLE = 6;
var I_BACK = 7;
var I_NEXT = 8;
var I_CANCEL = 9;
var I_DDNS_ENABLE = 10;
var I_SERVER_ADDRESS = 11;
var I_HOSTNAME = 12;
var I_UID = 13;
var I_PWD = 14;
var I_TIMEOUT = 15;
var I_HOURS = 16;

var des_item_name = new Array (
"Copyright 2014，D-Link Corporation/D-Link Systems, Inc。版权所有。",
"如果您有动态DNS帐号，并且希望您的摄像机自动升级IP地址，启用动态DNS并在下面输入您的主机信息。 \
点击 <b>下一步</b> 按钮继续。<br><br>",
""
);

var D_COPYRIGHT = 0;
var D_TITLE_IFNO = 1;

var option_content = new Array (
"选择一个动态DNS服务器",
""
);

var O_SELECT_DDNS_SERVER = 0;

var pop_msg = new Array (
"請求失敗",
"主机名格式无效。",
"用户名格式无效。",
"密码格式无效。",
"超时范围为240小时到65535小时。",
""
);

var PMSG_REQUEST_FAILED = 0;
var PMSG_INVALID_HOSTNAME = 1;
var PMSG_INVALID_UID = 2;
var PMSG_INVALID_PWD = 3;
var PMSG_INVALID_TIMEOUT_RANGE = 4;


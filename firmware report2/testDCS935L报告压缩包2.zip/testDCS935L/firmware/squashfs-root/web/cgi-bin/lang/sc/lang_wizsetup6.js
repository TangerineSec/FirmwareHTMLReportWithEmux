﻿var languageNum = new Array("en","sc","tc");
var item_name = new Array("D-LINK公司", "无线", "网络摄像机",
"实时视频",
"产品", 
"固件版本",
"第五步: 设置完成",
"返回",
"应用",
"取消",
"IP地址",
"IP摄像机名",
"时区",
"动态DNS",
"DHCP连接",
"PPPoE",
"启用",
"禁用",
""
);
var I_DINK_CORPORATION = 0;
var I_WIRELESS = 1;
var I_INTERNET_CAMERA = 2;
var I_LIVE_VIDEO = 3;
var I_PRODUCT = 4;
var I_FWVERSION = 5;
var I_TITLE = 6;
var I_BACK = 7;
var I_NEXT = 8;
var I_CANCEL = 9;
var I_IP_ADDRESS = 10;
var I_CAMERA_NAME = 11;
var I_TIMEZONE = 12;
var I_DDNS = 13;
var I_DHCP = 14;
var I_PPPOE = 15;
var I_ENABLE = 16;
var I_DISABLE = 17;

var des_item_name = new Array (
"Copyright 2014，D-Link Corporation/D-Link Systems, Inc。版权所有。",
"此处是摄像机设置概要。 点击 <b>返回</b> 查看或修改配置，如果所有配置都正确，则点击 <b>应用</b> 。\
建议记录下这些信息，以供将来查阅和参考。<br><br>",
""
);

var D_COPYRIGHT = 0;
var D_TITLE_IFNO = 1;

var pop_msg = new Array (
"請求失敗",
""
);

var PMSG_REQUEST_FAILED = 0;


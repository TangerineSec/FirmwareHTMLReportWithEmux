﻿var languageNum = new Array("en","sc","tc");
var item_name = new Array("站台搜尋", "重新整理", "選擇",
"離開", 
"加入",
"SSID",
"BSSID",
"頻道",
"加密",
"訊號 %",
"搜尋中",
"Ad-hoc (點對點網路)",
"無線基礎點模式",
"自動",
"無",
"WEP",
"WPA-PSK",
"WPA2-PSK",
"WPA-PSK/WPA2-PSK",
""
);

var I_SITE_SURVEY = 0;
var I_REFRESH = 1;
var I_SELECT = 2;
var I_EXIT = 3;
var I_JOIN = 4;
var I_SSID = 5;
var I_BSSID = 6;
var I_CHANNEL = 7;
var I_ENCRYPTION = 8;
var I_SIGNAL = 9;
var I_SEARCHING = 10;
var I_ADHOC = 11;
var I_INFRASTRUCTURE = 12;
var I_AUTOMATIC = 13;
var I_NO = 14;
var I_WEP = 15;
var I_WPAPSK = 16;
var I_WPA2PSK = 17;
var I_WPAWPA2PSK = 18;

var des_item_name = new Array (
"此功能會掃描裝置周圍可用的無線網路，並予以顯示。您可按<b>''重新整理''</b>來重新掃描、搜尋可用的無線網路。選取您要的無線網路，再按<b>選擇</b>繼續。",
""
);

var D_TITLE_INFO = 0;

var pop_msg = new Array (
"請求失敗",
""
);

var PMSG_REQUEST_FAILED = 0;

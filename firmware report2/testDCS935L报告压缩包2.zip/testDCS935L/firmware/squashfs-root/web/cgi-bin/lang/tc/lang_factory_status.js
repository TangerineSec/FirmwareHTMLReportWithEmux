﻿var languageNum = new Array("en","sc","tc");
var item_name = new Array("將所有設定回復成出廠預設值",
""
);
var I_RESTORE_FACTORY_DEFAULT = 0;

var des_item_name = new Array (
"攝影機已回復至原廠預設值。<br><br> \
攝影機重新啟動中，最多可能需要 60 秒的時間。<br><br>  \
與攝影機的連線已中斷。若重新啟動後，攝影機的網頁無法正常自動顯示，請使用攝影機隨附的設定精靈軟體來搜尋攝影機並連線。請等待 \
<SPAN ID=\"CountTime\"></SPAN> 秒 ...<br><br>",
""
);

var D_FACTORY_INFO = 0;
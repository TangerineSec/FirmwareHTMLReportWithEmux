﻿var languageNum = new Array("en","sc","tc");
var item_name = new Array("支援功能表", "裝置資訊", "系統日誌",
"事件日誌",
""
);
var I_SUPPORT_MENU = 0;
var I_DEVICE_INFO = 1;
var I_SYSTEM_LOG = 2;
var I_EVENT_LOG = 3;

var des_item_name = new Array (
"本頁會顯示攝影機與網路的所有詳細資訊。",
"檢視系統日誌檔。此檔案會記錄所有具參考價值的資訊，如系統開機訊息。",
"檢視事件日誌檔。此檔案會記錄所有具參考價值的資訊，如移動偵測通知。",
""
);

var D_DEVICE_INFO = 0;
var D_SYSTEM_LOG_INFO = 1;
var D_EVENT_LOG_INFO = 2;

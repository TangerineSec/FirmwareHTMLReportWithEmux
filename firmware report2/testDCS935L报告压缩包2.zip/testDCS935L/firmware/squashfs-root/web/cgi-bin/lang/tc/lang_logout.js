﻿var languageNum = new Array("en","sc","tc");
var item_name = new Array("友訊科技", "無線", "網際網路攝影機",
"即時影像",
"登出",
"登出會把瀏覽器關閉。",
"以手動方式關閉網頁。",
" 登出 ",
""
);
var I_DINK_CORPORATION = 0;
var I_WIRELESS = 1;
var I_INTERNET_CAMERA = 2;
var I_LIVE_VIDEO = 3;
var I_LOGOUT = 4;
var I_LOGOUT_CLICK_CLOSE_BROWSER = 5;
var I_LOGOUT_MANUALLY_CLOSE = 6;
var I_LOGOUT_2 = 7;

﻿var languageNum = new Array("en","sc","tc");
var item_name = new Array("重新啟動裝置",
""
);
var I_REBOOT_THE_DEVICE = 0;

var des_item_name = new Array (
"攝影機重新啟動中，最多可能需要 60 秒的時間。<br><br>\
與攝影機的連線已中斷。若重新啟動後，攝影機的網頁無法正常自動顯示，請使用攝影機隨附的設定精靈軟體來搜尋攝影機並連線。\
請等待 <SPAN ID=\"CountTime\"></SPAN> 秒 ...",
""
);

var D_REBOOT_INFO = 0;
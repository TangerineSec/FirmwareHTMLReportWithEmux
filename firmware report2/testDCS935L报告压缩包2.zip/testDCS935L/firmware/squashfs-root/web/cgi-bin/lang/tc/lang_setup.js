﻿var languageNum = new Array("en","sc","tc");
var item_name = new Array("友訊科技", "無線", "網際網路攝影機",
"即時影像",
"產品", 
"韌體版本", 
"即時影像",
"設定",
"維護",
"狀態",
"說明",
"精靈",
"網路設定",
"無線網路設定",
"延伸設定",
"動態DNS",
"IP 過濾器",
"影像設定",
"音訊和視訊",
"隱私遮罩",
"移動偵測",
"聲音偵測",
"電子郵件",
"FTP",
"快照",
"視訊短片",
"SD 錄影",
"SD卡管理",
"時間與日期",
"白天/夜晚模式",
"攝影機控制",
"登出",
"管理",
"系統",
"韌體更新",
"裝置資訊",
"系統日誌",
"事件日誌",
"功能表",
""
);
var I_DINK_CORPORATION = 0;
var I_WIRELESS = 1;
var I_INTERNET_CAMERA = 2;
var I_LIVE_VIDEO = 3;
var I_PRODUCT = 4;
var I_FWVERSION = 5;
var I_LIVE_VIDEO_2 = 6;
var I_SETUP = 7;
var I_MAINTENANCE = 8;
var I_STATUS = 9;
var I_HELP = 10;
var I_WIZARD = 11;
var I_NETWORK_SETUP = 12;
var I_WIRELESS_SETUP = 13;
var I_EXTENDER_SETUP = 14;
var I_DDNS = 15;
var I_IPFILTER = 16;
var I_IMAGE_SETUP = 17;
var I_AUDIO_VIDEO_SETUP = 18;
var I_PRIVACY_MASK = 19;
var I_MOTION_DETECTION = 20;
var I_SOUND_DETECTION = 21;
var I_MAIL = 22;
var I_FTP = 23;
var I_SNAPSHOT = 24;
var I_VIDEO_CLIP = 25;
var I_SD_RECORDING = 26;
var I_SD_MANAGEMENT = 27;
var I_TIME_AND_DATE = 28;
var I_DAY_NIGHT_MODE = 29;
var I_CAMERA_CONTROL = 30;
var I_LOGOUT = 31;
var I_ADMIN = 32;
var I_SYSTEM = 33;
var I_FW_UP = 34;
var I_DEVICE_INFO = 35;
var I_SYSTEM_LOG = 36;
var I_EVENT_LOG = 37;
var I_MENU = 38;

var des_item_name = new Array (
"版權所有 2014 友訊科技股份有限公司",
""
);

var D_COPYRIGHT = 0;

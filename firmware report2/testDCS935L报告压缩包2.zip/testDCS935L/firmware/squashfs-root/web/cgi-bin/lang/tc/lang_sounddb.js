﻿var languageNum = new Array("en","sc","tc");
var item_name = new Array("儲存設定值", "不要儲存設定", "儲存",
"聲音偵測", 
"聲音偵測設定",
"聲音偵測",
"啟用",
"停用",
"偵測音量",
"分貝",
""
);

var I_SAVE_SETTING = 0;
var I_NOT_SAVE_SETTING = 1;
var I_SAVING = 2;
var I_SOUND_DETECTION = 3;
var I_SOUND_DETECTION_SETTING = 4;
var I_SOUND_DETECTION_ITEM = 5;
var I_ENABLE = 6;
var I_DISABLE = 7;
var I_LEVEL = 8;
var I_DB = 9;

var des_item_name = new Array (
"您可以在此頁面進行攝影機的聲音偵測設定。\
<br><br>您的電腦必須安裝Java程式才能瀏覽分貝/時間的視窗。 若您沒有看到下方的聲音分貝/時間視窗， 請到\
<a href=\"http://www.java.com\">http://www.java.com</A>網站下載及安裝Java程式。",
"麥克風被禁用，請啟用麥克風。",
""
);

var D_TITLE_INFO = 0;
var D_MICROPHONE_DISABLED = 1;

var pop_msg = new Array (
"請求失敗",
""
);

var PMSG_REQUEST_FAILED = 0;

﻿var languageNum = new Array("en","sc","tc");
var item_name = new Array("裝置資訊", "基本資訊", "攝影機名稱",
"時間與日期",
"韌體版本",
"Agent版本",
"MAC 位址",
"IP 位址",
"子網路遮罩",
"預設閘道",
"主要 DNS",
"次要 DNS",
"DDNS",
"UPnP 通訊埠轉送",
"無線網路狀態",
"連線模式",
"連結",
"SSID",
"頻道",
"加密",
"重新整理",
"啟用",
"停用",
"無線基礎點模式",
"Ad-hoc (點對點網路)",
"是",
"否",
"無",
"WEP",
"WPA-PSK",
"WPA2-PSK",
"重新整理中",
"PPPoE 狀態",
"已連線",
"連線失敗",
"硬體版本",
""
);
var I_DEVICE_INFO = 0;
var I_BASIC_INFORMATION = 1;
var I_CAMERA_NAME = 2;
var I_TIME_AND_DATE = 3;
var I_FWVERSION = 4;
var I_AGENT_VERSION = 5;
var I_MAC_ADDRESS = 6;
var I_IP_ADDRESS = 7;
var I_SUBNET_MASK = 8;
var I_DEFAULT_GATEWAY = 9;
var I_PRIMARY_DNS = 10;
var I_SECONDARY_DNS = 11;
var I_DDNS = 12;
var I_UPNP_PORT_FORWARDING = 13;
var I_WIRELESS_STATUS = 14;
var I_CONNECTION_MODE = 15;
var I_LINK = 16;
var I_SSID = 17;
var I_CHANNEL = 18;
var I_ENCRYPTION = 19;
var I_REFRESH = 20;
var I_ENABLE = 21;
var I_DISABLE = 22;
var I_INFRASTRUCTURE = 23;
var I_ADHOC = 24;
var I_YES = 25;
var I_NO = 26;
var I_NONE = 27;
var I_WEP = 28;
var I_WPAPSK = 29;
var I_WPA2PSK = 30;
var I_REFRESHING = 31;
var I_PPPOE_STATUS = 32;
var I_PPPOE_CONNECT_SUCCESS = 33;
var I_PPPOE_CONNECT_FAIL = 34;
var I_HWVERSION = 35;

var des_item_name = new Array (
"所有網路連線詳細資料皆顯示於此頁面。也會顯示韌體版本資訊。",
"<b>說明項目..</b><br><br>所有網路連線詳細資料皆顯示於此頁面。",
""
);

var D_DEVICE_INFO = 0;
var D_HELP_INFO = 1;

﻿var languageNum = new Array("en","sc","tc");
var item_name = new Array("系統日誌", "目前日誌", "重新整理",
"重新整理中",
""
);
var I_SYSTEM_LOG = 0;
var I_CURRENT_LOG = 1;
var I_REFRESH = 2;
var I_REFRESHING = 3;

var des_item_name = new Array (
"系統日誌會記錄發生過的攝影機系統事件。",
"<b>說明項目..</b><br><br>您可按「重新整理」按鈕來刷新日誌。",
""
);

var D_SYSTEM_LOG_INFO = 0;
var D_HELP_INFO = 1;

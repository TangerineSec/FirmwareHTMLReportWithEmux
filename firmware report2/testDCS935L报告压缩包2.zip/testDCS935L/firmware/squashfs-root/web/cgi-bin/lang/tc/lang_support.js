﻿var languageNum = new Array("en","sc","tc");
var item_name = new Array("支援功能表", "即時影像", "設定",
"維護",
"狀態",
"攝影機",
"精靈",
"網路設定",
"無線網路設定",
"延伸設定",
"動態DNS",
"IP 過濾器",
"影像設定",
"音訊和視訊",
"隱私遮罩",
"移動偵測",
"聲音偵測",
"電子郵件",
"FTP",
"快照",
"視訊短片",
"時間與日期",
"白天/夜晚模式",
"管理",
"系統",
"韌體更新",
"裝置資訊",
"系統日誌",
"事件日誌",
"SD 卡管理",
""
);
var I_SUPPORT_MENU = 0;
var I_LIVE_VIDEO = 1;
var I_SETUP = 2;
var I_MAINTENANCE = 3;
var I_STATUS = 4;
var I_CAMERA = 5;
var I_WIZARD = 6;
var I_NETWORK_SETUP = 7;
var I_WIRELESS_SETUP = 8;
var I_EXTENDER_SETUP = 9;
var I_DYNAMIC_DNS = 10;
var I_IPFILTER = 11;
var I_IMAGE_SETUP = 12;
var I_AUDIO_AND_VIDEO = 13
var I_PRIVACY_MASK = 14;
var I_MOTION_DETECTION = 15;
var I_SOUND_DETECTION = 16;
var I_MAIL = 17;
var I_FTP = 18;
var I_SNAPSHOT = 19;
var I_VIDEO_CLIP = 20;
var I_TIME_AND_DATE = 21;
var I_DAY_NIGHT_MODE = 22;
var I_ADMIN = 23;
var I_SYSTEM = 24;
var I_FIRMWARE_UPGRADE = 25;
var I_DEVICE_INFO = 26;
var I_SYSTEM_LOG = 27;
var I_EVENT_LOG = 28;
var I_SD_MANAGEMENT = 29;
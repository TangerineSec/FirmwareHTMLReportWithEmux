﻿var languageNum = new Array("en","sc","tc");
var item_name = new Array("升級", "韌體更新完成。", "裝置正在執行韌體更新中。",
"檔案無效！",
"裝置正在執行韌體更新中，請稍待，可能最多需要 240 秒的時間完成作業。",
"秒",
""
);
var I_UPGRADE = 0;
var I_FIRMWARE_UPGRADE_OK = 1;
var I_FIRMWARE_IS_RUNNING = 2;
var I_FILE_INVALID = 3;
var I_WAIT_FW_RUNNING = 4;
var I_SEC = 5;

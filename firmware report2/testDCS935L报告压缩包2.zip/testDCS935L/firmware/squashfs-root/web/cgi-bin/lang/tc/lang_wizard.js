﻿var languageNum = new Array("en","sc","tc");
var item_name = new Array("網際網路連線設定", "網際網路連線設定精靈", "手動網際網路連線設定",
""
);
var I_INTERNET_CONNECTION_SETTING = 0;
var I_INTERNET_CONNECTION_SETUP = 1;
var I_MANAUAL_INTERNET_CONNECTION_SETUP = 2;

var des_item_name = new Array (
"本區可讓您設定 IP 攝影機的網路設定。若您是第一次設定本裝置，D-Link 建議您按網際網路連線設定精靈按鈕，\
並遵循畫面上的步驟進行。若想手動修改 IP 攝影機設定，請按手動網際網路連線設定按鈕。<br><br>",
"<b>說明項目..</b><br><br>若您是進階使用者，過去也曾設定過網際網路攝影機，請按<b>手動網際網路連線設定</b>，自行輸入所有參數。",
""
);

var D_WIZARD_INFO = 0;
var D_HELP_INFO = 1;

var pop_msg = new Array (
"請求失敗",
""
);

var PMSG_REQUEST_FAILED = 0;

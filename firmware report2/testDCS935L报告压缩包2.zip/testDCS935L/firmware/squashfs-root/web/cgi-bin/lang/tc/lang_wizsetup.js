﻿var languageNum = new Array("en","sc","tc");
var item_name = new Array("友訊科技", "無線", "網際網路攝影機",
"即時影像",
"產品", 
"韌體版本", 
"歡迎使用D-Link 設定精靈 – 網際網路連線設定",
"上一步",
"下一步",
"取消",
""
);
var I_DINK_CORPORATION = 0;
var I_WIRELESS = 1;
var I_INTERNET_CAMERA = 2;
var I_LIVE_VIDEO = 3;
var I_PRODUCT = 4;
var I_FWVERSION = 5;
var I_TITLE = 6;
var I_BACK = 7;
var I_NEXT = 8;
var I_CANCEL = 9;

var des_item_name = new Array (
"版權所有 2014 友訊科技股份有限公司",
"此精靈會一步一步引導您設定全新的 D-Link 攝影機，並將攝影機連上網際網路。<br><br>",
"<b>第 1 步：</b>設定 LAN",
"<b>第 2 步：</b>設定 DDNS",
"<b>第 3 步：</b>伺服器名稱設定",
"<b>第 4 步：</b>設定時區",
""
);

var D_COPYRIGHT = 0;
var D_TITLE_IFNO = 1;
var D_SETP1_INFO = 2;
var D_SETP2_INFO = 3;
var D_SETP3_INFO = 4;
var D_SETP4_INFO = 5;

﻿var languageNum = new Array("en","sc","tc");
var item_name = new Array("友訊科技", "無線", "網際網路攝影機",
"即時影像",
"產品", 
"韌體版本", 
"第 2 步：設定 DDNS",
"上一步",
"下一步",
"取消",
"動態DNS啟用",
"伺服器位址",
"主機名稱",
"使用者名稱",
"密碼",
"逾時",
"小時",
""
);
var I_DINK_CORPORATION = 0;
var I_WIRELESS = 1;
var I_INTERNET_CAMERA = 2;
var I_LIVE_VIDEO = 3;
var I_PRODUCT = 4;
var I_FWVERSION = 5;
var I_TITLE = 6;
var I_BACK = 7;
var I_NEXT = 8;
var I_CANCEL = 9;
var I_DDNS_ENABLE = 10;
var I_SERVER_ADDRESS = 11;
var I_HOSTNAME = 12;
var I_UID = 13;
var I_PWD = 14;
var I_TIMEOUT = 15;
var I_HOURS = 16;

var des_item_name = new Array (
"版權所有 2014 友訊科技股份有限公司",
"若您有動態 DNS 帳戶，想讓攝影機動態自動取得 IP 位址，請啟用 DDNS 並輸入主機資訊。按<b>下一步</b>繼續。<br><br>",
""
);

var D_COPYRIGHT = 0;
var D_TITLE_IFNO = 1;

var option_content = new Array (
"選取動態 DNS 伺服器位址",
""
);

var O_SELECT_DDNS_SERVER = 0;

var pop_msg = new Array (
"請求失敗",
"主機名稱格式無效。",
"使用者名稱格式無效。",
"密碼格式無效。",
"逾時值的範圍在 240 到 65535 小時之間。",
""
);

var PMSG_REQUEST_FAILED = 0;
var PMSG_INVALID_HOSTNAME = 1;
var PMSG_INVALID_UID = 2;
var PMSG_INVALID_PWD = 3;
var PMSG_INVALID_TIMEOUT_RANGE = 4;


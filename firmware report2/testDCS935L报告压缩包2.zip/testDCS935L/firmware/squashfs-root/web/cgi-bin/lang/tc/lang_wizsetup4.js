﻿var languageNum = new Array("en","sc","tc");
var item_name = new Array("友訊科技", "無線", "網際網路攝影機",
"即時影像",
"產品", 
"韌體版本", 
"第 3 步：伺服器名稱設定",
"上一步",
"下一步",
"取消",
"攝影機名稱",
"最多 10 字元",
""
);
var I_DINK_CORPORATION = 0;
var I_WIRELESS = 1;
var I_INTERNET_CAMERA = 2;
var I_LIVE_VIDEO = 3;
var I_PRODUCT = 4;
var I_FWVERSION = 5;
var I_TITLE = 6;
var I_BACK = 7;
var I_NEXT = 8;
var I_CANCEL = 9;
var I_CAMERA_NAME = 10;
var I_CAMERA_NAME_LENGTH_DES = 11;

var des_item_name = new Array (
"版權所有 2014 友訊科技股份有限公司",
"D-Link 建議您將攝影機重新命名以方便存取。請自己取一個名字再按<b>下一步</b>按鈕。<br><br>",
""
);

var D_COPYRIGHT = 0;
var D_TITLE_IFNO = 1;

var pop_msg = new Array (
"請求失敗",
"攝影機名稱格式無效。",
""
);

var PMSG_REQUEST_FAILED = 0;
var PMSG_CAMERA_NAME_INVALID = 1;


﻿var languageNum = new Array("en","sc","tc");
var item_name = new Array("友訊科技", "無線", "網際網路攝影機",
"即時影像",
"產品", 
"韌體版本", 
"第 5 步：設定完成",
"上一步",
"套用",
"取消",
"IP 位址",
"IP 攝影機名稱",
"時區",
"DDNS",
"DHCP連線",
"PPPoE",
"啟用",
"停用",
""
);
var I_DINK_CORPORATION = 0;
var I_WIRELESS = 1;
var I_INTERNET_CAMERA = 2;
var I_LIVE_VIDEO = 3;
var I_PRODUCT = 4;
var I_FWVERSION = 5;
var I_TITLE = 6;
var I_BACK = 7;
var I_NEXT = 8;
var I_CANCEL = 9;
var I_IP_ADDRESS = 10;
var I_CAMERA_NAME = 11;
var I_TIMEZONE = 12;
var I_DDNS = 13;
var I_DHCP = 14;
var I_PPPOE = 15;
var I_ENABLE = 16;
var I_DISABLE = 17;

var des_item_name = new Array (
"版權所有 2014 友訊科技股份有限公司",
"此為攝影機設定摘要。請按<b>上一步</b>檢查或修改設定，若所有設定均正確請按<b>套用</b>。建議您寫下這些資訊供未來參考。<br><br>",
""
);

var D_COPYRIGHT = 0;
var D_TITLE_IFNO = 1;

var pop_msg = new Array (
"請求失敗",
""
);

var PMSG_REQUEST_FAILED = 0;


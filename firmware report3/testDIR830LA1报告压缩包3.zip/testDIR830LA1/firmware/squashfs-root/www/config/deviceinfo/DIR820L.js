//These settings will override common settings
function DeviceInfo()
{
	this.bridgeMode = true;
	this.featureVPN = true;
	
	this.featureDLNA = false;
	this.featureUPNPAV = false;
	
	this.helpVer = "0100";
}

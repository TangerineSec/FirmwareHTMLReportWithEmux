//custom
function DeviceInfo()
{
	this.featureDLNA = true;
	
	this.helpVer = "0100";
}
